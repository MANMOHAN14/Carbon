import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import jwt from 'jsonwebtoken';

function verifyToken(request: NextRequest) {
  const authHeader = request.headers.get('authorization');
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    throw new Error('No token provided');
  }
  
  const token = authHeader.substring(7);
  return jwt.verify(token, process.env.JWT_SECRET || 'fallback-secret') as any;
}

export async function GET(request: NextRequest) {
  try {
    const decoded = verifyToken(request);
    
    const projects = await prisma.project.findMany({
      include: {
        owner: {
          select: { id: true, name: true, email: true, role: true }
        },
        carbonCredits: true,
        _count: {
          select: { dataEntries: true, verifications: true }
        }
      },
      orderBy: { createdAt: 'desc' }
    });

    return NextResponse.json({ projects });
  } catch (error) {
    console.error('Get projects error:', error);
    return NextResponse.json(
      { error: 'Unauthorized' },
      { status: 401 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const decoded = verifyToken(request);
    const { name, description, location, coordinates, area, ecosystem } = await request.json();

    if (!name || !description || !location || !coordinates || !area || !ecosystem) {
      return NextResponse.json(
        { error: 'All fields are required' },
        { status: 400 }
      );
    }

    const project = await prisma.project.create({
      data: {
        name,
        description,
        location,
        coordinates: JSON.stringify(coordinates),
        area: parseFloat(area),
        ecosystem,
        status: 'PLANNING',
        ownerId: decoded.userId
      },
      include: {
        owner: {
          select: { id: true, name: true, email: true, role: true }
        }
      }
    });

    return NextResponse.json({ project }, { status: 201 });
  } catch (error) {
    console.error('Create project error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
