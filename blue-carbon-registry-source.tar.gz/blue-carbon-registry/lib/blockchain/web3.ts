import { ethers } from 'ethers';

export interface Web3Provider {
  provider: ethers.BrowserProvider | null;
  signer: ethers.Signer | null;
  account: string | null;
}

export class Web3Service {
  private static instance: Web3Service;
  private provider: ethers.BrowserProvider | null = null;
  private signer: ethers.Signer | null = null;
  private account: string | null = null;

  static getInstance(): Web3Service {
    if (!Web3Service.instance) {
      Web3Service.instance = new Web3Service();
    }
    return Web3Service.instance;
  }

  async connectWallet(): Promise<Web3Provider> {
    if (typeof window !== 'undefined' && window.ethereum) {
      try {
        // Request account access
        await window.ethereum.request({ method: 'eth_requestAccounts' });
        
        this.provider = new ethers.BrowserProvider(window.ethereum);
        this.signer = await this.provider.getSigner();
        this.account = await this.signer.getAddress();

        return {
          provider: this.provider,
          signer: this.signer,
          account: this.account
        };
      } catch (error) {
        console.error('Failed to connect wallet:', error);
        throw error;
      }
    } else {
      throw new Error('MetaMask not installed');
    }
  }

  async getContract(contractAddress: string, abi: any) {
    if (!this.signer) {
      throw new Error('Wallet not connected');
    }
    return new ethers.Contract(contractAddress, abi, this.signer);
  }

  async issueCarbonCredit(
    contractAddress: string,
    to: string,
    projectId: string,
    amount: number,
    location: string,
    verificationHash: string,
    tokenURI: string
  ) {
    const contract = await this.getContract(contractAddress, CARBON_CREDIT_ABI);
    const tx = await contract.issueCarbonCredit(
      to,
      projectId,
      Math.floor(amount * 1000), // Convert to wei-like format
      location,
      verificationHash,
      tokenURI
    );
    return await tx.wait();
  }

  async retireCredit(contractAddress: string, tokenId: number) {
    const contract = await this.getContract(contractAddress, CARBON_CREDIT_ABI);
    const tx = await contract.retireCredit(tokenId);
    return await tx.wait();
  }

  async getCreditDetails(contractAddress: string, tokenId: number) {
    const contract = await this.getContract(contractAddress, CARBON_CREDIT_ABI);
    return await contract.getCreditDetails(tokenId);
  }

  getProvider(): Web3Provider {
    return {
      provider: this.provider,
      signer: this.signer,
      account: this.account
    };
  }
}

// Simplified ABI for the carbon credit contract
export const CARBON_CREDIT_ABI = [
  "function issueCarbonCredit(address to, string projectId, uint256 amount, string location, string verificationHash, string tokenURI) returns (uint256)",
  "function retireCredit(uint256 tokenId)",
  "function getCreditDetails(uint256 tokenId) view returns (tuple(uint256 amount, string projectId, string location, uint256 issuedAt, bool retired, string verificationHash))",
  "function getProjectTokens(string projectId) view returns (uint256[])",
  "function ownerOf(uint256 tokenId) view returns (address)",
  "function tokenURI(uint256 tokenId) view returns (string)",
  "event CreditIssued(uint256 indexed tokenId, string projectId, uint256 amount)",
  "event CreditRetired(uint256 indexed tokenId, address by)",
  "event CreditTransferred(uint256 indexed tokenId, address from, address to)"
];

declare global {
  interface Window {
    ethereum?: any;
  }
}
