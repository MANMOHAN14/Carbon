'use client';

import { useRef, useEffect, useState } from 'react';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import { OrbitControls, Sphere, Text } from '@react-three/drei';
import * as THREE from 'three';

interface EarthMetrics {
  co2Level: number;
  toxicityLevel: number;
  temperature: number;
  humanPopulation: number;
  animalPopulation: number;
  plantPopulation: number;
  oceanAcidity: number;
  iceCapMelting: number;
}

interface GlobeProps {
  metrics: EarthMetrics;
  pollutionLevel: number;
}

function Earth({ metrics, pollutionLevel }: GlobeProps) {
  const meshRef = useRef<THREE.Mesh>(null);
  const [hovered, setHovered] = useState(false);

  useFrame((state) => {
    if (meshRef.current) {
      meshRef.current.rotation.y += 0.005;
    }
  });

  // Calculate earth color based on pollution and health
  const getEarthColor = () => {
    const healthScore = (
      (100 - metrics.co2Level) +
      (100 - metrics.toxicityLevel) +
      (100 - metrics.temperature) +
      (100 - metrics.oceanAcidity)
    ) / 4;

    if (healthScore > 80) return '#4ade80'; // Green - healthy
    if (healthScore > 60) return '#facc15'; // Yellow - warning
    if (healthScore > 40) return '#f97316'; // Orange - concerning
    return '#ef4444'; // Red - critical
  };

  // Create texture for the earth
  const createEarthTexture = () => {
    const canvas = document.createElement('canvas');
    canvas.width = 512;
    canvas.height = 256;
    const ctx = canvas.getContext('2d')!;

    // Base earth color
    ctx.fillStyle = getEarthColor();
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Add pollution clouds
    if (pollutionLevel > 30) {
      ctx.fillStyle = `rgba(139, 69, 19, ${pollutionLevel / 100})`;
      for (let i = 0; i < 20; i++) {
        const x = Math.random() * canvas.width;
        const y = Math.random() * canvas.height;
        const radius = Math.random() * 30 + 10;
        ctx.beginPath();
        ctx.arc(x, y, radius, 0, Math.PI * 2);
        ctx.fill();
      }
    }

    // Add ice caps (shrinking based on melting)
    const iceOpacity = Math.max(0.1, 1 - metrics.iceCapMelting / 100);
    ctx.fillStyle = `rgba(255, 255, 255, ${iceOpacity})`;
    
    // North pole
    ctx.beginPath();
    ctx.arc(canvas.width / 2, 30, 40, 0, Math.PI * 2);
    ctx.fill();
    
    // South pole
    ctx.beginPath();
    ctx.arc(canvas.width / 2, canvas.height - 30, 40, 0, Math.PI * 2);
    ctx.fill();

    return new THREE.CanvasTexture(canvas);
  };

  const texture = createEarthTexture();

  return (
    <group>
      <Sphere
        ref={meshRef}
        args={[2, 64, 64]}
        onPointerOver={() => setHovered(true)}
        onPointerOut={() => setHovered(false)}
        scale={hovered ? 1.1 : 1}
      >
        <meshStandardMaterial
          map={texture}
          transparent
          opacity={0.9}
        />
      </Sphere>
      
      {/* Atmosphere effect */}
      <Sphere args={[2.1, 32, 32]}>
        <meshBasicMaterial
          color={pollutionLevel > 50 ? '#8b4513' : '#87ceeb'}
          transparent
          opacity={0.1}
          side={THREE.BackSide}
        />
      </Sphere>

      {/* Warning indicators */}
      {metrics.co2Level > 80 && (
        <Text
          position={[0, 3, 0]}
          fontSize={0.3}
          color="red"
          anchorX="center"
          anchorY="middle"
        >
          CRITICAL CO2 LEVELS
        </Text>
      )}
    </group>
  );
}

function Scene({ metrics, pollutionLevel }: GlobeProps) {
  const { camera } = useThree();
  
  useEffect(() => {
    camera.position.set(0, 0, 6);
  }, [camera]);

  return (
    <>
      <ambientLight intensity={0.4} />
      <pointLight position={[10, 10, 10]} intensity={1} />
      <Earth metrics={metrics} pollutionLevel={pollutionLevel} />
      <OrbitControls
        enableZoom={true}
        enablePan={false}
        enableRotate={true}
        autoRotate={false}
        maxDistance={10}
        minDistance={3}
      />
    </>
  );
}

export default function Globe({ metrics, pollutionLevel }: GlobeProps) {
  return (
    <div className="w-full h-full">
      <Canvas>
        <Scene metrics={metrics} pollutionLevel={pollutionLevel} />
      </Canvas>
    </div>
  );
}
