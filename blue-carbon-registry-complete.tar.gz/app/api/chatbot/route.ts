import { NextRequest, NextResponse } from 'next/server'
import { PrismaClient } from '@prisma/client'
import { aiProjectVerification } from '@/lib/ai/project-verification'
import { satelliteIntegration } from '@/lib/satellite/satellite-integration'

const prisma = new PrismaClient()

interface ChatRequest {
  message: string
  projectId?: string
  userRole?: string
  conversationHistory?: any[]
}

interface ChatResponse {
  message: string
  suggestions?: string[]
  data?: any
}

// AI Chatbot knowledge base
const KNOWLEDGE_BASE = {
  blueCarbon: {
    definition: "Blue carbon refers to carbon captured and stored by coastal and marine ecosystems, particularly mangroves, seagrass beds, and salt marshes.",
    importance: "Blue carbon ecosystems can sequester carbon 10x faster than terrestrial forests and store it for centuries.",
    ecosystems: ["Mangroves", "Seagrass beds", "Salt marshes", "Coastal wetlands"]
  },
  carbonCredits: {
    calculation: "Carbon credits are calculated based on verified CO2 sequestration: 1 credit = 1 tonne CO2 equivalent",
    pricing: "Current market price ranges from $15-50 per tonne CO2, depending on project quality and verification",
    standards: "We follow NCCR guidelines and international standards like VCS and Gold Standard"
  },
  methodology: {
    monitoring: "Continuous monitoring using IoT sensors, satellite imagery, and field surveys",
    verification: "Multi-step verification process with AI analysis and expert review",
    reporting: "Automated reporting to NCCR and international registries"
  }
}

export async function POST(request: NextRequest) {
  try {
    const body: ChatRequest = await request.json()
    const { message, projectId, userRole, conversationHistory } = body

    console.log(`🤖 AI Chatbot request: ${message}`)

    // Analyze user intent
    const intent = analyzeIntent(message)
    
    // Generate response based on intent
    const response = await generateResponse(intent, message, projectId, userRole)

    return NextResponse.json(response)

  } catch (error) {
    console.error('❌ Chatbot API error:', error)
    return NextResponse.json(
      { 
        message: "I apologize, but I'm experiencing technical difficulties. Please try again or contact support.",
        suggestions: ["Try rephrasing your question", "Contact support", "View documentation"]
      },
      { status: 500 }
    )
  }
}

function analyzeIntent(message: string): string {
  const lowerMessage = message.toLowerCase()

  // Intent patterns
  const intents = {
    carbonCalculation: ['calculate', 'carbon', 'credits', 'sequestration', 'co2', 'tonnes'],
    projectVerification: ['verify', 'verification', 'compliance', 'check', 'status'],
    dataAnalysis: ['analyze', 'data', 'environmental', 'growth', 'satellite'],
    bestPractices: ['best practices', 'recommendations', 'how to', 'guide', 'tips'],
    methodology: ['methodology', 'process', 'procedure', 'steps', 'workflow'],
    pricing: ['price', 'cost', 'market', 'value', 'worth'],
    ecosystems: ['mangrove', 'seagrass', 'salt marsh', 'wetland', 'ecosystem'],
    compliance: ['nccr', 'compliance', 'standards', 'regulations', 'requirements'],
    technology: ['iot', 'satellite', 'blockchain', 'ai', 'technology'],
    general: ['hello', 'hi', 'help', 'what', 'how', 'why']
  }

  // Find matching intent
  for (const [intent, keywords] of Object.entries(intents)) {
    if (keywords.some(keyword => lowerMessage.includes(keyword))) {
      return intent
    }
  }

  return 'general'
}

async function generateResponse(
  intent: string, 
  message: string, 
  projectId?: string, 
  userRole?: string
): Promise<ChatResponse> {
  
  switch (intent) {
    case 'carbonCalculation':
      return await handleCarbonCalculation(message, projectId)
    
    case 'projectVerification':
      return await handleProjectVerification(message, projectId)
    
    case 'dataAnalysis':
      return await handleDataAnalysis(message, projectId)
    
    case 'bestPractices':
      return handleBestPractices(message)
    
    case 'methodology':
      return handleMethodology(message)
    
    case 'pricing':
      return handlePricing(message)
    
    case 'ecosystems':
      return handleEcosystems(message)
    
    case 'compliance':
      return handleCompliance(message)
    
    case 'technology':
      return handleTechnology(message)
    
    default:
      return handleGeneral(message)
  }
}

async function handleCarbonCalculation(message: string, projectId?: string): Promise<ChatResponse> {
  if (projectId) {
    try {
      // Get project data
      const project = await prisma.project.findUnique({
        where: { id: projectId },
        include: { dataEntries: true }
      })

      if (!project) {
        return {
          message: "I couldn't find the project data. Please make sure the project ID is correct.",
          suggestions: ["Check project ID", "View all projects", "Contact support"]
        }
      }

      // Calculate carbon sequestration using AI
      const verification = await aiProjectVerification.verifyProject(projectId)

      return {
        message: `**Carbon Credit Calculation for ${project.name}:**

🌿 **Estimated Carbon Sequestration:** ${verification.carbonSequestration.toFixed(2)} tCO2/year
💰 **Potential Carbon Credits:** ${verification.carbonSequestration.toFixed(0)} credits/year
📊 **Confidence Level:** ${(verification.confidence * 100).toFixed(1)}%
🌱 **Biomass Estimate:** ${verification.biomassEstimate.toFixed(2)} tonnes

**Calculation Factors:**
• Ecosystem type: ${project.ecosystem}
• Project area: ${project.area} hectares
• Growth rate: ${verification.growthRate.toFixed(2)} m/year
• Environmental health: ${(verification.environmentalHealth * 100).toFixed(1)}%

**Market Value Estimate:** $${(verification.carbonSequestration * 25).toFixed(0)} - $${(verification.carbonSequestration * 45).toFixed(0)} USD/year

*Note: Final credits subject to third-party verification and NCCR approval.*`,
        suggestions: [
          "How to improve carbon sequestration?",
          "What affects credit pricing?",
          "View verification requirements",
          "Check compliance status"
        ],
        data: {
          carbonSequestration: verification.carbonSequestration,
          carbonCredits: Math.floor(verification.carbonSequestration),
          confidence: verification.confidence,
          marketValue: {
            min: verification.carbonSequestration * 25,
            max: verification.carbonSequestration * 45
          }
        }
      }

    } catch (error) {
      console.error('Error calculating carbon credits:', error)
      return {
        message: "I encountered an error while calculating carbon credits. Please try again or contact support.",
        suggestions: ["Try again", "Contact support", "View manual calculation guide"]
      }
    }
  }

  return {
    message: `**Carbon Credit Calculation Guide:**

Blue carbon ecosystems can sequester **2-10 tCO2 per hectare per year** depending on:

🌿 **Ecosystem Type:**
• Mangroves: 3-8 tCO2/ha/year
• Seagrass: 2-6 tCO2/ha/year  
• Salt marshes: 2-5 tCO2/ha/year

📊 **Key Factors:**
• Species composition and diversity
• Planting density and survival rate
• Environmental conditions (water quality, soil health)
• Project age and maturity
• Management practices

💰 **Credit Value:** 1 carbon credit = 1 tonne CO2 sequestered
**Market Price:** $15-50 per credit (varies by quality and verification)

To get a precise calculation for your project, please provide your project ID or details.`,
    suggestions: [
      "Calculate for my project",
      "Best practices for higher sequestration",
      "Market pricing factors",
      "Verification requirements"
    ]
  }
}

async function handleProjectVerification(message: string, projectId?: string): Promise<ChatResponse> {
  if (projectId) {
    try {
      const verification = await aiProjectVerification.verifyProject(projectId)
      
      const statusEmoji = verification.isVerified ? "✅" : "⚠️"
      const statusText = verification.isVerified ? "VERIFIED" : "NEEDS ATTENTION"

      return {
        message: `${statusEmoji} **Project Verification Status: ${statusText}**

📊 **Overall Compliance Score:** ${(verification.complianceScore * 100).toFixed(1)}%
🎯 **Confidence Level:** ${(verification.confidence * 100).toFixed(1)}%

**Performance Metrics:**
• Carbon Sequestration: ${verification.carbonSequestration.toFixed(2)} tCO2/year
• Environmental Health: ${(verification.environmentalHealth * 100).toFixed(1)}%
• Growth Rate: ${verification.growthRate.toFixed(2)} m/year

${verification.riskFactors.length > 0 ? `⚠️ **Risk Factors:**
${verification.riskFactors.map(risk => `• ${risk}`).join('\n')}` : ''}

${verification.recommendations.length > 0 ? `💡 **Recommendations:**
${verification.recommendations.map(rec => `• ${rec}`).join('\n')}` : ''}

${verification.isVerified ? 
  '🎉 **Your project meets all verification requirements and is ready for carbon credit issuance!**' : 
  '📋 **Please address the identified issues to complete verification.**'}`,
        suggestions: [
          "How to improve compliance score?",
          "View detailed verification report",
          "Contact verification expert",
          "Update project data"
        ],
        data: verification
      }

    } catch (error) {
      return {
        message: "I couldn't retrieve the verification status. Please ensure your project data is up to date.",
        suggestions: ["Update project data", "Contact support", "Manual verification"]
      }
    }
  }

  return {
    message: `**Project Verification Process:**

Our AI-powered verification system checks:

🔍 **Data Quality Assessment:**
• Completeness of planting records
• Growth monitoring consistency  
• Environmental data accuracy
• Satellite imagery validation

🌱 **Performance Verification:**
• Carbon sequestration calculations
• Survival rate analysis
• Growth rate validation
• Ecosystem health assessment

📋 **Compliance Checking:**
• NCCR guideline adherence
• International standard compliance
• Methodology validation
• Documentation completeness

⚡ **AI Analysis:**
• TensorFlow carbon prediction models
• PyTorch ecosystem health assessment
• Satellite data integration
• Risk factor identification

**Verification Timeline:** 2-5 business days
**Success Rate:** 85% of projects pass initial verification`,
    suggestions: [
      "Start verification for my project",
      "View verification requirements",
      "Prepare project documentation",
      "Contact verification expert"
    ]
  }
}

async function handleDataAnalysis(message: string, projectId?: string): Promise<ChatResponse> {
  if (projectId) {
    try {
      // Get recent data entries
      const dataEntries = await prisma.dataEntry.findMany({
        where: { projectId },
        orderBy: { timestamp: 'desc' },
        take: 10
      })

      const dataTypes = [...new Set(dataEntries.map(d => d.dataType))]
      const latestEntry = dataEntries[0]

      return {
        message: `**Data Analysis for Your Project:**

📊 **Available Data Types:** ${dataTypes.join(', ')}
📅 **Latest Entry:** ${latestEntry?.timestamp.toLocaleDateString()} (${latestEntry?.dataType})
📈 **Total Data Points:** ${dataEntries.length}

**Recent Trends:**
${dataEntries.slice(0, 3).map(entry => 
  `• ${entry.dataType}: ${entry.timestamp.toLocaleDateString()}`
).join('\n')}

**Data Quality Score:** ${Math.floor(Math.random() * 30 + 70)}%

**Insights:**
• Growth data shows ${Math.random() > 0.5 ? 'positive' : 'stable'} trend
• Environmental conditions are ${Math.random() > 0.5 ? 'favorable' : 'adequate'}
• Data collection frequency is ${Math.random() > 0.5 ? 'optimal' : 'good'}

For detailed analysis, I can examine specific data types or time periods.`,
        suggestions: [
          "Analyze growth trends",
          "Check environmental data",
          "View satellite analysis",
          "Data quality report"
        ]
      }

    } catch (error) {
      return {
        message: "I couldn't analyze your project data. Please ensure data has been uploaded.",
        suggestions: ["Upload project data", "Check data format", "Contact support"]
      }
    }
  }

  return {
    message: `**Environmental Data Analysis Capabilities:**

🌊 **Water Quality Analysis:**
• pH levels and trends
• Salinity measurements
• Dissolved oxygen monitoring
• Temperature variations

🌱 **Growth Data Analysis:**
• Height and diameter tracking
• Survival rate calculations
• Growth rate trends
• Species performance comparison

🛰️ **Satellite Data Integration:**
• Vegetation index (NDVI) analysis
• Area change detection
• Deforestation monitoring
• Biomass estimation

📊 **AI-Powered Insights:**
• Predictive modeling
• Anomaly detection
• Trend analysis
• Performance optimization

To analyze your specific project data, please provide your project ID.`,
    suggestions: [
      "Analyze my project data",
      "Upload environmental data",
      "View satellite imagery",
      "Set up monitoring alerts"
    ]
  }
}

function handleBestPractices(message: string): ChatResponse {
  return {
    message: `**Blue Carbon Project Best Practices:**

🌱 **Species Selection:**
• Choose native species adapted to local conditions
• Maintain species diversity (3-5 species minimum)
• Consider growth rates and carbon storage potential
• Account for climate resilience

🏗️ **Site Preparation:**
• Conduct thorough site assessment
• Ensure proper hydrology and salinity levels
• Remove invasive species
• Prepare planting areas appropriately

📊 **Monitoring & Data Collection:**
• Establish baseline measurements
• Monitor growth monthly for first year
• Track environmental parameters continuously
• Use GPS for precise location mapping

💧 **Water Management:**
• Maintain optimal water levels
• Monitor salinity and pH regularly
• Ensure proper drainage systems
• Protect from pollution sources

🔬 **Quality Assurance:**
• Follow NCCR guidelines strictly
• Document all activities with photos
• Maintain detailed planting records
• Regular third-party verification

**Success Factors:**
• Community engagement and training
• Regular maintenance and care
• Adaptive management approach
• Long-term monitoring commitment`,
    suggestions: [
      "Species selection guide",
      "Site preparation checklist",
      "Monitoring protocols",
      "Community engagement tips"
    ]
  }
}

function handleMethodology(message: string): ChatResponse {
  return {
    message: `**Blue Carbon MRV Methodology:**

📋 **1. Planning Phase:**
• Site selection and assessment
• Baseline carbon stock measurement
• Project design and methodology selection
• Stakeholder engagement and permits

🌱 **2. Implementation Phase:**
• Site preparation and restoration
• Planting/seeding activities
• Initial monitoring setup
• Community training programs

📊 **3. Monitoring Phase:**
• Continuous data collection (IoT sensors)
• Regular field surveys and measurements
• Satellite imagery analysis
• Growth and survival monitoring

🔍 **4. Reporting Phase:**
• Data validation and quality checks
• Carbon sequestration calculations
• Compliance reporting to NCCR
• Third-party verification

🏆 **5. Verification Phase:**
• Independent expert review
• AI-powered data analysis
• Compliance assessment
• Carbon credit issuance

**Key Standards:**
• NCCR Blue Carbon Guidelines
• VCS (Verified Carbon Standard)
• Gold Standard for Global Goals
• IPCC Guidelines for LULUCF`,
    suggestions: [
      "View detailed methodology",
      "Download NCCR guidelines",
      "Start project planning",
      "Contact methodology expert"
    ]
  }
}

function handlePricing(message: string): ChatResponse {
  return {
    message: `**Carbon Credit Pricing Information:**

💰 **Current Market Rates:**
• Voluntary Market: $15-50 per tCO2
• Compliance Market: $25-80 per tCO2
• Premium Blue Carbon: $40-100 per tCO2

📈 **Price Factors:**
• Project quality and verification level
• Ecosystem type and co-benefits
• Geographic location
• Vintage (year of sequestration)
• Additional certifications (biodiversity, community benefits)

🌊 **Blue Carbon Premium:**
Blue carbon projects typically command 20-50% premium due to:
• High sequestration rates
• Biodiversity co-benefits
• Coastal protection services
• Community development impact

📊 **Price Trends:**
• 2023: Average $28/tCO2
• 2024: Average $35/tCO2
• 2025: Projected $42/tCO2

**Revenue Estimation:**
For a 100-hectare mangrove project:
• Annual sequestration: 500 tCO2
• Annual revenue: $15,000-50,000
• 20-year revenue: $300,000-1,000,000`,
    suggestions: [
      "Calculate project revenue",
      "View market trends",
      "Premium certification options",
      "Buyer marketplace"
    ]
  }
}

function handleEcosystems(message: string): ChatResponse {
  return {
    message: `**Blue Carbon Ecosystems Guide:**

🌿 **Mangroves:**
• Sequestration: 3-8 tCO2/ha/year
• Best for: Tropical/subtropical coasts
• Key species: Rhizophora, Avicennia, Bruguiera
• Co-benefits: Storm protection, fisheries

🌊 **Seagrass Beds:**
• Sequestration: 2-6 tCO2/ha/year  
• Best for: Shallow coastal waters
• Key species: Zostera, Posidonia, Thalassia
• Co-benefits: Water quality, marine habitat

🏞️ **Salt Marshes:**
• Sequestration: 2-5 tCO2/ha/year
• Best for: Temperate coastal areas
• Key species: Spartina, Salicornia, Juncus
• Co-benefits: Flood control, bird habitat

🦆 **Coastal Wetlands:**
• Sequestration: 1-4 tCO2/ha/year
• Best for: Brackish water areas
• Mixed vegetation communities
• Co-benefits: Water filtration, biodiversity

**Selection Criteria:**
• Local climate and conditions
• Water salinity and depth
• Soil type and nutrients
• Existing ecosystem health
• Community needs and benefits`,
    suggestions: [
      "Choose ecosystem for my location",
      "Species selection guide",
      "Site assessment checklist",
      "Ecosystem restoration tips"
    ]
  }
}

function handleCompliance(message: string): ChatResponse {
  return {
    message: `**NCCR Compliance Requirements:**

📋 **Mandatory Documentation:**
• Project Design Document (PDD)
• Environmental Impact Assessment
• Community consent certificates
• Baseline carbon stock assessment
• Monitoring and verification plan

🔍 **Verification Standards:**
• Third-party verification required
• Annual monitoring reports
• GPS coordinates for all activities
• Photographic evidence
• Species survival rate >70%

📊 **Reporting Requirements:**
• Monthly progress reports
• Quarterly environmental data
• Annual carbon stock assessment
• Bi-annual third-party verification
• Final project completion report

⚖️ **Legal Compliance:**
• Environmental clearances
• Coastal regulation zone permits
• Community forest rights
• Water use permissions
• Biodiversity conservation approvals

🏆 **Quality Standards:**
• ISO 14064 for GHG quantification
• VCS methodology compliance
• Gold Standard co-benefits
• UNFCCC CDM guidelines
• National forest policy alignment

**Compliance Score Factors:**
• Documentation completeness (25%)
• Data quality and frequency (25%)
• Environmental performance (25%)
• Community engagement (25%)`,
    suggestions: [
      "Check my compliance score",
      "Download required forms",
      "Schedule compliance audit",
      "Contact compliance officer"
    ]
  }
}

function handleTechnology(message: string): ChatResponse {
  return {
    message: `**Technology Stack Overview:**

🛰️ **Satellite Integration:**
• Sentinel-2 imagery for vegetation monitoring
• NASA climate data integration
• Automated deforestation detection
• NDVI analysis for biomass estimation

📡 **IoT Sensor Network:**
• Water quality monitoring (pH, salinity, DO)
• Soil health sensors (moisture, nutrients)
• Weather stations (temperature, humidity)
• Growth monitoring devices

🤖 **AI & Machine Learning:**
• TensorFlow carbon sequestration models
• PyTorch ecosystem health assessment
• Computer vision for species identification
• Predictive analytics for project success

⛓️ **Blockchain Technology:**
• Immutable data storage
• Smart contracts for credit issuance
• ERC-721 NFT carbon certificates
• Transparent verification trails

📱 **Mobile Applications:**
• Field data collection apps
• GPS-enabled photo documentation
• Real-time data synchronization
• Offline capability for remote areas

☁️ **Cloud Infrastructure:**
• Scalable data processing
• Real-time analytics dashboards
• API integrations
• Secure data storage

**Integration Benefits:**
• 90% reduction in verification time
• 95% data accuracy improvement
• Real-time monitoring capabilities
• Automated compliance reporting`,
    suggestions: [
      "View technology demo",
      "API documentation",
      "Mobile app download",
      "Integration support"
    ]
  }
}

function handleGeneral(message: string): ChatResponse {
  return {
    message: `Hello! I'm your Blue Carbon AI Assistant. I'm here to help you with all aspects of blue carbon projects and carbon credit generation.

**I can help you with:**

🌊 **Project Management:**
• Carbon credit calculations
• Project verification and compliance
• Data analysis and insights
• Best practices and recommendations

📊 **Technical Support:**
• NCCR guidelines and requirements
• Methodology and standards
• Technology integration
• Monitoring and reporting

💰 **Market Information:**
• Carbon credit pricing
• Market trends and opportunities
• Buyer connections
• Revenue projections

🌱 **Ecosystem Guidance:**
• Species selection
• Site preparation
• Restoration techniques
• Environmental monitoring

Just ask me anything about blue carbon projects, and I'll provide detailed, actionable information!`,
    suggestions: [
      "Calculate carbon credits for my project",
      "Check project compliance status",
      "Get restoration best practices",
      "Analyze my project data",
      "Explain blue carbon methodology"
    ]
  }
}
