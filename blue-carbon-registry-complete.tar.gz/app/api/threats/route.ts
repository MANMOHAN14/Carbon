import { NextRequest, NextResponse } from 'next/server'
import { PrismaClient } from '@prisma/client'
import { satelliteIntegration } from '@/lib/satellite/satellite-integration'
import { mqttClient } from '@/lib/iot/mqtt-client'

const prisma = new PrismaClient()

interface ThreatAlert {
  id: string
  type: 'deforestation' | 'pollution' | 'erosion' | 'temperature' | 'salinity' | 'human_activity'
  severity: 'low' | 'medium' | 'high' | 'critical'
  location: { latitude: number; longitude: number }
  description: string
  timestamp: Date
  projectId: string
  source: 'satellite' | 'iot' | 'manual' | 'ai_prediction'
  confidence: number
  actionRequired: boolean
  metadata?: any
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const projectId = searchParams.get('projectId')
    const severity = searchParams.get('severity')
    const limit = parseInt(searchParams.get('limit') || '50')

    console.log(`🚨 Fetching threats for project: ${projectId}`)

    // Get real-time threats from multiple sources
    const threats = await Promise.all([
      getSatelliteThreats(projectId),
      getIoTThreats(projectId),
      getAIPredictedThreats(projectId),
      getStoredThreats(projectId, severity, limit)
    ])

    const allThreats = threats.flat().sort((a, b) => 
      new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
    )

    // Filter by severity if specified
    const filteredThreats = severity 
      ? allThreats.filter(t => t.severity === severity)
      : allThreats

    return NextResponse.json({
      success: true,
      threats: filteredThreats.slice(0, limit),
      summary: {
        total: filteredThreats.length,
        critical: filteredThreats.filter(t => t.severity === 'critical').length,
        high: filteredThreats.filter(t => t.severity === 'high').length,
        medium: filteredThreats.filter(t => t.severity === 'medium').length,
        low: filteredThreats.filter(t => t.severity === 'low').length,
        actionRequired: filteredThreats.filter(t => t.actionRequired).length
      }
    })

  } catch (error) {
    console.error('❌ Error fetching threats:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to fetch threats' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { type, severity, location, description, projectId, source, confidence, metadata } = body

    console.log(`🚨 Creating new threat alert: ${type}`)

    // Store threat in database
    const threat = await prisma.threatAlert.create({
      data: {
        type,
        severity,
        location: JSON.stringify(location),
        description,
        projectId,
        source,
        confidence,
        actionRequired: severity === 'critical' || severity === 'high',
        metadata: metadata ? JSON.stringify(metadata) : null,
        timestamp: new Date()
      }
    })

    // Send notifications for critical threats
    if (severity === 'critical') {
      await sendCriticalThreatNotification(threat)
    }

    return NextResponse.json({
      success: true,
      threat: {
        ...threat,
        location: JSON.parse(threat.location),
        metadata: threat.metadata ? JSON.parse(threat.metadata) : null
      }
    })

  } catch (error) {
    console.error('❌ Error creating threat alert:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to create threat alert' },
      { status: 500 }
    )
  }
}

async function getSatelliteThreats(projectId?: string | null): Promise<ThreatAlert[]> {
  try {
    console.log('🛰️ Analyzing satellite data for threats...')

    // Get projects to monitor
    const projects = projectId 
      ? await prisma.project.findMany({ where: { id: projectId } })
      : await prisma.project.findMany({ take: 10 })

    const threats: ThreatAlert[] = []

    for (const project of projects) {
      try {
        // Analyze satellite data for deforestation
        const satelliteData = await satelliteIntegration.getSentinelImagery(
          project.latitude,
          project.longitude,
          new Date(Date.now() - 30 * 24 * 60 * 60 * 1000), // Last 30 days
          new Date()
        )

        // Check for deforestation
        if (satelliteData.deforestationDetected) {
          threats.push({
            id: `sat-defor-${project.id}-${Date.now()}`,
            type: 'deforestation',
            severity: satelliteData.deforestationArea > 1 ? 'critical' : 'high',
            location: { latitude: project.latitude, longitude: project.longitude },
            description: `Satellite imagery shows ${satelliteData.deforestationArea.toFixed(2)} hectares of forest loss detected`,
            timestamp: new Date(),
            projectId: project.id,
            source: 'satellite',
            confidence: satelliteData.confidence,
            actionRequired: true,
            metadata: {
              area: satelliteData.deforestationArea,
              ndvi_change: satelliteData.ndviChange,
              detection_date: satelliteData.detectionDate
            }
          })
        }

        // Check for coastal erosion
        const erosionRate = await calculateErosionRate(project.latitude, project.longitude)
        if (erosionRate > 2.0) { // More than 2m/year
          threats.push({
            id: `sat-erosion-${project.id}-${Date.now()}`,
            type: 'erosion',
            severity: erosionRate > 5 ? 'critical' : 'high',
            location: { latitude: project.latitude, longitude: project.longitude },
            description: `Coastal erosion rate increased to ${erosionRate.toFixed(1)}m/year, threatening ${project.ecosystem} ecosystem`,
            timestamp: new Date(),
            projectId: project.id,
            source: 'satellite',
            confidence: 0.85,
            actionRequired: true,
            metadata: {
              erosion_rate: erosionRate,
              affected_length: Math.random() * 2 + 0.5 // km
            }
          })
        }

      } catch (error) {
        console.error(`Error analyzing satellite data for project ${project.id}:`, error)
      }
    }

    return threats

  } catch (error) {
    console.error('Error getting satellite threats:', error)
    return []
  }
}

async function getIoTThreats(projectId?: string | null): Promise<ThreatAlert[]> {
  try {
    console.log('📡 Analyzing IoT sensor data for threats...')

    // Get recent IoT data
    const whereClause = projectId ? { projectId } : {}
    const recentData = await prisma.dataEntry.findMany({
      where: {
        ...whereClause,
        timestamp: {
          gte: new Date(Date.now() - 24 * 60 * 60 * 1000) // Last 24 hours
        }
      },
      orderBy: { timestamp: 'desc' },
      take: 100
    })

    const threats: ThreatAlert[] = []

    // Group data by project and type
    const dataByProject = recentData.reduce((acc, entry) => {
      if (!acc[entry.projectId]) acc[entry.projectId] = {}
      if (!acc[entry.projectId][entry.dataType]) acc[entry.projectId][entry.dataType] = []
      acc[entry.projectId][entry.dataType].push(entry)
      return acc
    }, {} as any)

    for (const [projId, projectData] of Object.entries(dataByProject)) {
      const project = await prisma.project.findUnique({ where: { id: projId } })
      if (!project) continue

      // Check water quality threats
      if (projectData.water_quality) {
        const latestWQ = projectData.water_quality[0]
        const wqData = JSON.parse(latestWQ.data)

        // Check for pollution
        if (wqData.nitrogen > 10 || wqData.phosphorus > 2 || wqData.ph < 6.5 || wqData.ph > 8.5) {
          threats.push({
            id: `iot-pollution-${projId}-${Date.now()}`,
            type: 'pollution',
            severity: wqData.nitrogen > 15 ? 'high' : 'medium',
            location: { latitude: project.latitude, longitude: project.longitude },
            description: `Water quality sensors detect pollution: Nitrogen ${wqData.nitrogen.toFixed(1)} mg/L, pH ${wqData.ph.toFixed(1)}`,
            timestamp: new Date(latestWQ.timestamp),
            projectId: projId,
            source: 'iot',
            confidence: 0.95,
            actionRequired: wqData.nitrogen > 12,
            metadata: wqData
          })
        }
      }

      // Check temperature anomalies
      if (projectData.weather) {
        const latestWeather = projectData.weather[0]
        const weatherData = JSON.parse(latestWeather.data)
        const seasonalAvg = getSeasonalAverage(project.latitude, new Date().getMonth())

        if (Math.abs(weatherData.temperature - seasonalAvg) > 3) {
          threats.push({
            id: `iot-temp-${projId}-${Date.now()}`,
            type: 'temperature',
            severity: Math.abs(weatherData.temperature - seasonalAvg) > 5 ? 'high' : 'medium',
            location: { latitude: project.latitude, longitude: project.longitude },
            description: `Temperature anomaly: ${weatherData.temperature.toFixed(1)}°C (${(weatherData.temperature - seasonalAvg).toFixed(1)}°C above seasonal average)`,
            timestamp: new Date(latestWeather.timestamp),
            projectId: projId,
            source: 'iot',
            confidence: 0.87,
            actionRequired: Math.abs(weatherData.temperature - seasonalAvg) > 4,
            metadata: {
              current_temp: weatherData.temperature,
              seasonal_avg: seasonalAvg,
              anomaly: weatherData.temperature - seasonalAvg
            }
          })
        }
      }

      // Check salinity levels
      if (projectData.soil) {
        const latestSoil = projectData.soil[0]
        const soilData = JSON.parse(latestSoil.data)

        if (soilData.salinity > 35 || soilData.salinity < 15) { // ppt
          threats.push({
            id: `iot-salinity-${projId}-${Date.now()}`,
            type: 'salinity',
            severity: soilData.salinity > 40 || soilData.salinity < 10 ? 'high' : 'medium',
            location: { latitude: project.latitude, longitude: project.longitude },
            description: `Salinity levels ${soilData.salinity > 35 ? 'too high' : 'too low'}: ${soilData.salinity.toFixed(1)} ppt`,
            timestamp: new Date(latestSoil.timestamp),
            projectId: projId,
            source: 'iot',
            confidence: 0.92,
            actionRequired: soilData.salinity > 40 || soilData.salinity < 10,
            metadata: soilData
          })
        }
      }
    }

    return threats

  } catch (error) {
    console.error('Error getting IoT threats:', error)
    return []
  }
}

async function getAIPredictedThreats(projectId?: string | null): Promise<ThreatAlert[]> {
  try {
    console.log('🤖 Generating AI threat predictions...')

    const threats: ThreatAlert[] = []

    // Get projects for prediction
    const projects = projectId 
      ? await prisma.project.findMany({ where: { id: projectId } })
      : await prisma.project.findMany({ take: 5 })

    for (const project of projects) {
      // Predict pollution events based on patterns
      const pollutionRisk = await predictPollutionRisk(project)
      if (pollutionRisk.probability > 0.7) {
        threats.push({
          id: `ai-pollution-${project.id}-${Date.now()}`,
          type: 'pollution',
          severity: pollutionRisk.probability > 0.85 ? 'high' : 'medium',
          location: { latitude: project.latitude, longitude: project.longitude },
          description: `AI models predict ${(pollutionRisk.probability * 100).toFixed(0)}% probability of pollution event in next ${pollutionRisk.timeframe} hours`,
          timestamp: new Date(),
          projectId: project.id,
          source: 'ai_prediction',
          confidence: pollutionRisk.confidence,
          actionRequired: pollutionRisk.probability > 0.8,
          metadata: pollutionRisk
        })
      }

      // Predict human activity threats
      const humanActivityRisk = await predictHumanActivityThreat(project)
      if (humanActivityRisk.probability > 0.6) {
        threats.push({
          id: `ai-human-${project.id}-${Date.now()}`,
          type: 'human_activity',
          severity: humanActivityRisk.severity,
          location: { latitude: project.latitude, longitude: project.longitude },
          description: humanActivityRisk.description,
          timestamp: new Date(),
          projectId: project.id,
          source: 'ai_prediction',
          confidence: humanActivityRisk.confidence,
          actionRequired: humanActivityRisk.probability > 0.75,
          metadata: humanActivityRisk
        })
      }
    }

    return threats

  } catch (error) {
    console.error('Error getting AI predicted threats:', error)
    return []
  }
}

async function getStoredThreats(projectId?: string | null, severity?: string | null, limit: number = 50): Promise<ThreatAlert[]> {
  try {
    const whereClause: any = {}
    if (projectId) whereClause.projectId = projectId
    if (severity) whereClause.severity = severity

    const storedThreats = await prisma.threatAlert.findMany({
      where: whereClause,
      orderBy: { timestamp: 'desc' },
      take: limit
    })

    return storedThreats.map(threat => ({
      ...threat,
      location: JSON.parse(threat.location),
      metadata: threat.metadata ? JSON.parse(threat.metadata) : null
    }))

  } catch (error) {
    console.error('Error getting stored threats:', error)
    return []
  }
}

async function calculateErosionRate(latitude: number, longitude: number): Promise<number> {
  // Simulate erosion rate calculation based on location and historical data
  const coastalFactor = Math.abs(latitude) < 30 ? 1.5 : 1.0 // Tropical coasts erode faster
  const baseRate = Math.random() * 3 + 0.5 // 0.5-3.5 m/year base rate
  return baseRate * coastalFactor
}

function getSeasonalAverage(latitude: number, month: number): number {
  // Simplified seasonal temperature calculation
  const isNorthern = latitude > 0
  const seasonalVariation = Math.sin((month - (isNorthern ? 0 : 6)) * Math.PI / 6) * 10
  const baseTemp = 25 - Math.abs(latitude) * 0.5 // Cooler at higher latitudes
  return baseTemp + seasonalVariation
}

async function predictPollutionRisk(project: any): Promise<any> {
  // Simulate AI pollution risk prediction
  const industrialProximity = Math.random() * 0.4 + 0.1 // 0.1-0.5
  const weatherFactor = Math.random() * 0.3 + 0.1 // 0.1-0.4
  const historicalFactor = Math.random() * 0.3 + 0.1 // 0.1-0.4
  
  const probability = industrialProximity + weatherFactor + historicalFactor
  
  return {
    probability: Math.min(probability, 0.95),
    confidence: 0.73 + Math.random() * 0.2,
    timeframe: Math.floor(Math.random() * 48 + 12), // 12-60 hours
    factors: {
      industrial_activity: industrialProximity,
      weather_conditions: weatherFactor,
      historical_patterns: historicalFactor
    }
  }
}

async function predictHumanActivityThreat(project: any): Promise<any> {
  const activities = [
    'Unauthorized boat activity detected in protected area',
    'Illegal fishing activity predicted based on seasonal patterns',
    'Construction activity detected near ecosystem boundary',
    'Tourist activity exceeding carrying capacity'
  ]

  const activity = activities[Math.floor(Math.random() * activities.length)]
  const probability = Math.random() * 0.4 + 0.5 // 0.5-0.9

  return {
    probability,
    confidence: 0.65 + Math.random() * 0.25,
    severity: probability > 0.8 ? 'high' : 'medium',
    description: activity,
    predicted_impact: 'Moderate to high ecosystem disruption'
  }
}

async function sendCriticalThreatNotification(threat: any): Promise<void> {
  try {
    console.log(`🚨 Sending critical threat notification for: ${threat.type}`)
    
    // Here you would integrate with notification services:
    // - Email notifications
    // - SMS alerts
    // - Push notifications
    // - Webhook calls to external systems
    
    // For now, just log the notification
    console.log(`Critical threat notification sent: ${threat.description}`)
    
  } catch (error) {
    console.error('Error sending critical threat notification:', error)
  }
}
