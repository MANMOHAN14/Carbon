import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import jwt from 'jsonwebtoken';

function verifyToken(request: NextRequest) {
  const authHeader = request.headers.get('authorization');
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    throw new Error('No token provided');
  }
  
  const token = authHeader.substring(7);
  return jwt.verify(token, process.env.JWT_SECRET || 'fallback-secret') as any;
}

export async function POST(request: NextRequest) {
  try {
    const decoded = verifyToken(request);
    const { projectId, type, value, coordinates, source, metadata } = await request.json();

    if (!projectId || !type || !value || !source) {
      return NextResponse.json(
        { error: 'ProjectId, type, value, and source are required' },
        { status: 400 }
      );
    }

    // Verify project exists and user has access
    const project = await prisma.project.findFirst({
      where: {
        id: projectId,
        OR: [
          { ownerId: decoded.userId },
          { owner: { role: { in: ['ADMIN', 'VERIFIER'] } } }
        ]
      }
    });

    if (!project) {
      return NextResponse.json(
        { error: 'Project not found or access denied' },
        { status: 404 }
      );
    }

    const dataEntry = await prisma.dataEntry.create({
      data: {
        projectId,
        type,
        value: JSON.stringify(value),
        coordinates: coordinates ? JSON.stringify(coordinates) : null,
        source,
        metadata: metadata ? JSON.stringify(metadata) : null,
        timestamp: new Date(),
        submitterId: decoded.userId
      },
      include: {
        project: {
          select: { name: true, location: true }
        },
        submitter: {
          select: { name: true, role: true }
        }
      }
    });

    return NextResponse.json({ dataEntry }, { status: 201 });
  } catch (error) {
    console.error('Create data entry error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

export async function GET(request: NextRequest) {
  try {
    const decoded = verifyToken(request);
    const { searchParams } = new URL(request.url);
    const projectId = searchParams.get('projectId');

    let whereClause = {};
    if (projectId) {
      whereClause = { projectId };
    }

    const dataEntries = await prisma.dataEntry.findMany({
      where: whereClause,
      include: {
        project: {
          select: { name: true, location: true }
        },
        submitter: {
          select: { name: true, role: true }
        }
      },
      orderBy: { timestamp: 'desc' }
    });

    return NextResponse.json({ dataEntries });
  } catch (error) {
    console.error('Get data entries error:', error);
    return NextResponse.json(
      { error: 'Unauthorized' },
      { status: 401 }
    );
  }
}
