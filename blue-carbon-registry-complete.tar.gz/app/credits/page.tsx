"use client";

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Leaf, 
  ArrowLeft, 
  Award, 
  TrendingUp, 
  ExternalLink,
  Plus,
  Coins
} from 'lucide-react';
import Link from 'next/link';
import { toast } from 'sonner';
import WalletConnect from '@/components/blockchain/WalletConnect';

interface CarbonCredit {
  id: string;
  amount: number;
  price: number | null;
  status: string;
  tokenId: string | null;
  contractAddress: string | null;
  createdAt: string;
  project: {
    name: string;
    location: string;
    ecosystem: string;
    owner: {
      name: string;
    };
  };
}

export default function CarbonCreditsPage() {
  const [credits, setCredits] = useState<CarbonCredit[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [connectedAccount, setConnectedAccount] = useState<string | null>(null);
  const router = useRouter();

  useEffect(() => {
    const token = localStorage.getItem('token');
    if (!token) {
      router.push('/auth/login');
      return;
    }

    fetchCredits(token);
  }, [router]);

  const fetchCredits = async (token: string) => {
    try {
      const response = await fetch('/api/credits', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });

      if (response.ok) {
        const data = await response.json();
        setCredits(data.carbonCredits);
      } else {
        toast.error('Failed to fetch carbon credits');
      }
    } catch (error) {
      toast.error('Network error');
    } finally {
      setIsLoading(false);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'ISSUED': return 'bg-green-100 text-green-800';
      case 'PENDING': return 'bg-yellow-100 text-yellow-800';
      case 'TRADED': return 'bg-blue-100 text-blue-800';
      case 'RETIRED': return 'bg-gray-100 text-gray-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getEcosystemIcon = (ecosystem: string) => {
    switch (ecosystem) {
      case 'MANGROVE': return '🌿';
      case 'SEAGRASS': return '🌊';
      case 'SALT_MARSH': return '🏞️';
      case 'COASTAL_WETLAND': return '🦆';
      default: return '🌱';
    }
  };

  const totalCredits = credits.reduce((sum, credit) => sum + credit.amount, 0);
  const issuedCredits = credits.filter(c => c.status === 'ISSUED').length;
  const totalValue = credits.reduce((sum, credit) => sum + (credit.price || 0) * credit.amount, 0);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <Leaf className="h-12 w-12 text-green-600 mx-auto mb-4 animate-spin" />
          <p className="text-gray-600">Loading carbon credits...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Navigation */}
      <nav className="bg-white border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-2">
              <Leaf className="h-8 w-8 text-green-600" />
              <span className="text-xl font-bold text-gray-900">Blue Carbon Registry</span>
            </div>
            <Link href="/dashboard">
              <Button variant="ghost">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to Dashboard
              </Button>
            </Link>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Carbon Credits</h1>
          <p className="text-gray-600 mt-2">Blockchain-verified carbon credits from blue carbon projects</p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Credits</CardTitle>
              <Award className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{totalCredits.toFixed(2)}</div>
              <p className="text-xs text-muted-foreground">tonnes CO2 equivalent</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Issued Credits</CardTitle>
              <Coins className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{issuedCredits}</div>
              <p className="text-xs text-muted-foreground">blockchain tokens</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Value</CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">${totalValue.toFixed(2)}</div>
              <p className="text-xs text-muted-foreground">estimated market value</p>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Credits List */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle>Carbon Credits Registry</CardTitle>
                <CardDescription>
                  All carbon credits generated from blue carbon projects
                </CardDescription>
              </CardHeader>
              <CardContent>
                {credits.length === 0 ? (
                  <div className="text-center py-12">
                    <Award className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                    <h3 className="text-lg font-medium text-gray-900 mb-2">No carbon credits yet</h3>
                    <p className="text-gray-600">
                      Carbon credits will appear here once projects are verified and credits are issued
                    </p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {credits.map((credit) => (
                      <div key={credit.id} className="border rounded-lg p-4 hover:shadow-md transition-shadow">
                        <div className="flex items-start justify-between">
                          <div className="flex items-start space-x-3">
                            <span className="text-2xl">{getEcosystemIcon(credit.project.ecosystem)}</span>
                            <div>
                              <h3 className="font-medium text-gray-900">{credit.project.name}</h3>
                              <p className="text-sm text-gray-600">{credit.project.location}</p>
                              <p className="text-xs text-gray-500">Owner: {credit.project.owner.name}</p>
                            </div>
                          </div>
                          <Badge className={getStatusColor(credit.status)}>
                            {credit.status}
                          </Badge>
                        </div>
                        
                        <div className="mt-4 grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                          <div>
                            <span className="text-gray-600">Amount:</span>
                            <div className="font-medium">{credit.amount} tCO2</div>
                          </div>
                          <div>
                            <span className="text-gray-600">Price:</span>
                            <div className="font-medium">
                              {credit.price ? `$${credit.price}/tCO2` : 'Not set'}
                            </div>
                          </div>
                          <div>
                            <span className="text-gray-600">Token ID:</span>
                            <div className="font-medium">
                              {credit.tokenId ? `#${credit.tokenId}` : 'Pending'}
                            </div>
                          </div>
                          <div>
                            <span className="text-gray-600">Issued:</span>
                            <div className="font-medium">
                              {new Date(credit.createdAt).toLocaleDateString()}
                            </div>
                          </div>
                        </div>

                        {credit.contractAddress && credit.tokenId && (
                          <div className="mt-4 flex space-x-2">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => window.open(`https://etherscan.io/token/${credit.contractAddress}?a=${credit.tokenId}`, '_blank')}
                            >
                              <ExternalLink className="h-3 w-3 mr-1" />
                              View on Etherscan
                            </Button>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Wallet & Blockchain Integration */}
          <div className="space-y-6">
            <WalletConnect 
              onConnect={setConnectedAccount}
              onDisconnect={() => setConnectedAccount(null)}
            />

            <Card>
              <CardHeader>
                <CardTitle>Blockchain Integration</CardTitle>
                <CardDescription>
                  Interact with carbon credit smart contracts
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="text-sm text-gray-600">
                    <p className="mb-2">Features available with connected wallet:</p>
                    <ul className="space-y-1 text-xs">
                      <li>• View token ownership</li>
                      <li>• Transfer credits</li>
                      <li>• Retire credits</li>
                      <li>• Verify authenticity</li>
                    </ul>
                  </div>
                  
                  {!connectedAccount && (
                    <div className="text-center py-4">
                      <p className="text-sm text-gray-500 mb-2">Connect wallet to access blockchain features</p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Market Information</CardTitle>
                <CardDescription>
                  Carbon credit market insights
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Average Price:</span>
                    <span className="font-medium">$25-50/tCO2</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Market Trend:</span>
                    <span className="font-medium text-green-600">↗ Growing</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Blue Carbon Premium:</span>
                    <span className="font-medium">15-30%</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
