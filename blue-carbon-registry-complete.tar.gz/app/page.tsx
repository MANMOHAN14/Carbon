"use client";

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Leaf, 
  Shield, 
  Database, 
  Users, 
  TrendingUp, 
  MapPin, 
  Smartphone,
  Drone,
  Award,
  BarChart3,
  Globe as GlobeIcon,
  Zap
} from 'lucide-react';
import Link from 'next/link';
import { motion } from 'framer-motion';
import dynamic from 'next/dynamic';

// Dynamically import the ClimateSimulator to avoid SSR issues
const ClimateSimulator = dynamic(
  () => import('@/components/climate-simulator/ClimateSimulator'),
  { ssr: false }
);

export default function HomePage() {
  const [mounted, setMounted] = useState(false);
  const [showClimateSimulator, setShowClimateSimulator] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  if (!mounted) return null;

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-green-50 to-teal-50">
      {/* Navigation */}
      <nav className="border-b bg-white/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-2">
              <Leaf className="h-8 w-8 text-green-600" />
              <span className="text-xl font-bold text-gray-900">Blue Carbon Registry</span>
            </div>
            <div className="flex items-center space-x-4">
              <Button
                variant="ghost"
                onClick={() => setShowClimateSimulator(!showClimateSimulator)}
                className="flex items-center gap-2"
              >
                <GlobeIcon className="h-4 w-4" />
                {showClimateSimulator ? 'Hide' : 'Show'} Climate Simulator
              </Button>
              <Link href="/auth/login">
                <Button variant="ghost">Login</Button>
              </Link>
              <Link href="/auth/register">
                <Button>Get Started</Button>
              </Link>
            </div>
          </div>
        </div>
      </nav>

      {/* Climate Simulator Modal/Overlay */}
      {showClimateSimulator && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm"
          onClick={() => setShowClimateSimulator(false)}
        >
          <div 
            className="absolute inset-4 bg-white rounded-2xl overflow-hidden shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="absolute top-4 right-4 z-10">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowClimateSimulator(false)}
                className="bg-white/80 backdrop-blur-sm"
              >
                ✕ Close
              </Button>
            </div>
            <ClimateSimulator />
          </div>
        </motion.div>
      )}

      {/* Hero Section with Climate Impact */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            {/* Left side - Text content */}
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
            >
              <h1 className="text-5xl md:text-6xl font-bold text-gray-900 mb-6">
                Blockchain-Powered
                <span className="text-green-600 block">Blue Carbon Registry</span>
              </h1>
              <p className="text-xl text-gray-600 mb-8">
                Decentralized Monitoring, Reporting, and Verification (MRV) system for blue carbon 
                ecosystem restoration with transparent carbon credit tokenization.
              </p>
              
              {/* Climate Impact Alert */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.3 }}
                className="bg-gradient-to-r from-red-100 to-orange-100 border border-red-200 rounded-lg p-4 mb-6"
              >
                <div className="flex items-center gap-3 mb-2">
                  <Zap className="h-5 w-5 text-red-600" />
                  <span className="font-semibold text-red-800">Climate Emergency Alert</span>
                </div>
                <p className="text-red-700 text-sm mb-3">
                  Current CO2 levels: <strong>420+ ppm</strong> • Ocean pH dropping • Ice caps melting
                </p>
                <Button
                  onClick={() => setShowClimateSimulator(true)}
                  size="sm"
                  className="bg-red-600 hover:bg-red-700 text-white"
                >
                  <GlobeIcon className="h-4 w-4 mr-2" />
                  View AI Climate Simulation
                </Button>
              </motion.div>

              <div className="flex flex-col sm:flex-row gap-4">
                <Link href="/auth/register">
                  <Button size="lg" className="bg-green-600 hover:bg-green-700">
                    Start Your Project
                  </Button>
                </Link>
                <Link href="/dashboard">
                  <Button size="lg" variant="outline">
                    View Registry
                  </Button>
                </Link>
              </div>
            </motion.div>

            {/* Right side - Interactive Climate Preview */}
            <motion.div
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="relative"
            >
              <div className="bg-gradient-to-br from-blue-900 via-slate-800 to-green-900 rounded-2xl p-8 text-white relative overflow-hidden">
                {/* Background pattern */}
                <div className="absolute inset-0 opacity-10">
                  <div className="absolute inset-0 bg-gradient-to-r from-blue-400 to-green-400 transform rotate-12 scale-150"></div>
                </div>
                
                <div className="relative z-10">
                  <h3 className="text-2xl font-bold mb-6 flex items-center gap-2">
                    <GlobeIcon className="h-6 w-6 text-blue-400" />
                    Earth's Climate Status
                  </h3>
                  
                  {/* Climate metrics preview */}
                  <div className="grid grid-cols-2 gap-4 mb-6">
                    <div className="bg-white/10 backdrop-blur-sm rounded-lg p-3">
                      <div className="text-red-400 text-2xl font-bold">420 ppm</div>
                      <div className="text-sm text-gray-300">CO2 Levels</div>
                      <div className="w-full bg-gray-700 rounded-full h-2 mt-2">
                        <div className="bg-red-500 h-2 rounded-full" style={{ width: '85%' }}></div>
                      </div>
                    </div>
                    <div className="bg-white/10 backdrop-blur-sm rounded-lg p-3">
                      <div className="text-orange-400 text-2xl font-bold">1.2°C</div>
                      <div className="text-sm text-gray-300">Temperature Rise</div>
                      <div className="w-full bg-gray-700 rounded-full h-2 mt-2">
                        <div className="bg-orange-500 h-2 rounded-full" style={{ width: '60%' }}></div>
                      </div>
                    </div>
                    <div className="bg-white/10 backdrop-blur-sm rounded-lg p-3">
                      <div className="text-yellow-400 text-2xl font-bold">8.1 pH</div>
                      <div className="text-sm text-gray-300">Ocean Acidity</div>
                      <div className="w-full bg-gray-700 rounded-full h-2 mt-2">
                        <div className="bg-yellow-500 h-2 rounded-full" style={{ width: '70%' }}></div>
                      </div>
                    </div>
                    <div className="bg-white/10 backdrop-blur-sm rounded-lg p-3">
                      <div className="text-blue-400 text-2xl font-bold">15%</div>
                      <div className="text-sm text-gray-300">Ice Cap Loss</div>
                      <div className="w-full bg-gray-700 rounded-full h-2 mt-2">
                        <div className="bg-blue-500 h-2 rounded-full" style={{ width: '15%' }}></div>
                      </div>
                    </div>
                  </div>

                  {/* Blue Carbon Impact */}
                  <div className="bg-gradient-to-r from-green-600/20 to-teal-600/20 rounded-lg p-4 mb-4">
                    <h4 className="font-semibold text-green-400 mb-2">Blue Carbon Solution Impact</h4>
                    <div className="text-sm text-gray-300 space-y-1">
                      <div>• Potential CO2 reduction: <span className="text-green-400 font-semibold">-126 ppm</span></div>
                      <div>• Ocean health improvement: <span className="text-teal-400 font-semibold">+16.2%</span></div>
                      <div>• Ecosystem restoration: <span className="text-blue-400 font-semibold">1M+ hectares</span></div>
                    </div>
                  </div>

                  <Button
                    onClick={() => setShowClimateSimulator(true)}
                    className="w-full bg-gradient-to-r from-blue-600 to-green-600 hover:from-blue-700 hover:to-green-700"
                  >
                    <Zap className="h-4 w-4 mr-2" />
                    Launch Full AI Climate Simulator
                  </Button>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Complete Blue Carbon MRV Solution
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Empowering NGOs, coastal panchayats, and communities with transparent, 
              verifiable carbon credit generation through blockchain technology.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.1 }}
            >
              <Card className="h-full hover:shadow-lg transition-shadow">
                <CardHeader>
                  <Shield className="h-12 w-12 text-blue-600 mb-4" />
                  <CardTitle>Immutable Data Storage</CardTitle>
                  <CardDescription>
                    Verified plantation and restoration data stored permanently on blockchain
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2 text-sm text-gray-600">
                    <li>• Tamper-proof records</li>
                    <li>• Transparent verification</li>
                    <li>• Audit trail maintenance</li>
                  </ul>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
            >
              <Card className="h-full hover:shadow-lg transition-shadow">
                <CardHeader>
                  <Award className="h-12 w-12 text-green-600 mb-4" />
                  <CardTitle>Tokenized Carbon Credits</CardTitle>
                  <CardDescription>
                    Smart contracts automatically generate tradeable carbon credits
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2 text-sm text-gray-600">
                    <li>• ERC-721 NFT tokens</li>
                    <li>• Automated issuance</li>
                    <li>• Marketplace integration</li>
                  </ul>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.3 }}
            >
              <Card className="h-full hover:shadow-lg transition-shadow">
                <CardHeader>
                  <Users className="h-12 w-12 text-purple-600 mb-4" />
                  <CardTitle>Multi-Stakeholder Platform</CardTitle>
                  <CardDescription>
                    Role-based access for NGOs, panchayats, researchers, and verifiers
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2 text-sm text-gray-600">
                    <li>• Community onboarding</li>
                    <li>• Permission management</li>
                    <li>• Collaborative workflows</li>
                  </ul>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.4 }}
            >
              <Card className="h-full hover:shadow-lg transition-shadow">
                <CardHeader>
                  <Smartphone className="h-12 w-12 text-orange-600 mb-4" />
                  <CardTitle>Mobile Data Collection</CardTitle>
                  <CardDescription>
                    Field teams can upload GPS, species count, and environmental data
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2 text-sm text-gray-600">
                    <li>• Real-time data upload</li>
                    <li>• GPS integration</li>
                    <li>• Photo documentation</li>
                  </ul>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.5 }}
            >
              <Card className="h-full hover:shadow-lg transition-shadow">
                <CardHeader>
                  <Drone className="h-12 w-12 text-teal-600 mb-4" />
                  <CardTitle>Drone & Satellite Integration</CardTitle>
                  <CardDescription>
                    Automated monitoring through aerial surveys and satellite imagery
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2 text-sm text-gray-600">
                    <li>• Aerial photography</li>
                    <li>• Growth monitoring</li>
                    <li>• Area calculations</li>
                  </ul>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.6 }}
            >
              <Card className="h-full hover:shadow-lg transition-shadow">
                <CardHeader>
                  <BarChart3 className="h-12 w-12 text-red-600 mb-4" />
                  <CardTitle>Analytics Dashboard</CardTitle>
                  <CardDescription>
                    Comprehensive reporting and visualization for NCCR compliance
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2 text-sm text-gray-600">
                    <li>• Real-time metrics</li>
                    <li>• Compliance reporting</li>
                    <li>• Impact visualization</li>
                  </ul>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Ecosystem Types */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-gray-50">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Supported Blue Carbon Ecosystems
            </h2>
            <p className="text-xl text-gray-600">
              Comprehensive monitoring for all major coastal carbon sinks
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { name: 'Mangroves', icon: '🌿', description: 'Coastal forest ecosystems' },
              { name: 'Seagrass', icon: '🌊', description: 'Underwater meadows' },
              { name: 'Salt Marshes', icon: '🏞️', description: 'Tidal wetlands' },
              { name: 'Coastal Wetlands', icon: '🦆', description: 'Brackish ecosystems' }
            ].map((ecosystem, index) => (
              <motion.div
                key={ecosystem.name}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                <Card className="text-center hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <div className="text-4xl mb-2">{ecosystem.icon}</div>
                    <CardTitle className="text-lg">{ecosystem.name}</CardTitle>
                    <CardDescription>{ecosystem.description}</CardDescription>
                  </CardHeader>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-green-600 text-white">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 text-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              <div className="text-4xl font-bold mb-2">1,000+</div>
              <div className="text-green-100">Hectares Monitored</div>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.1 }}
            >
              <div className="text-4xl font-bold mb-2">50+</div>
              <div className="text-green-100">Active Projects</div>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
            >
              <div className="text-4xl font-bold mb-2">25,000</div>
              <div className="text-green-100">Carbon Credits Issued</div>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.3 }}
            >
              <div className="text-4xl font-bold mb-2">100+</div>
              <div className="text-green-100">Community Partners</div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-white">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl font-bold text-gray-900 mb-6">
            Ready to Start Your Blue Carbon Project?
          </h2>
          <p className="text-xl text-gray-600 mb-8">
            Join the decentralized movement for transparent, verifiable carbon credit generation
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/auth/register">
              <Button size="lg" className="bg-green-600 hover:bg-green-700">
                Register Your Organization
              </Button>
            </Link>
            <Link href="/dashboard">
              <Button size="lg" variant="outline">
                Explore Registry
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <Leaf className="h-6 w-6 text-green-400" />
                <span className="text-lg font-bold">Blue Carbon Registry</span>
              </div>
              <p className="text-gray-400">
                Blockchain-powered MRV system for blue carbon ecosystem restoration
              </p>
            </div>
            <div>
              <h3 className="font-semibold mb-4">Platform</h3>
              <ul className="space-y-2 text-gray-400">
                <li><Link href="/dashboard" className="hover:text-white">Dashboard</Link></li>
                <li><Link href="/projects" className="hover:text-white">Projects</Link></li>
                <li><Link href="/credits" className="hover:text-white">Carbon Credits</Link></li>
                <li><Link href="/data" className="hover:text-white">Data Portal</Link></li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-4">Resources</h3>
              <ul className="space-y-2 text-gray-400">
                <li><Link href="/docs" className="hover:text-white">Documentation</Link></li>
                <li><Link href="/api" className="hover:text-white">API Reference</Link></li>
                <li><Link href="/support" className="hover:text-white">Support</Link></li>
                <li><Link href="/community" className="hover:text-white">Community</Link></li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-4">Contact</h3>
              <ul className="space-y-2 text-gray-400">
                <li>Email: info@bluecarbonregistry.org</li>
                <li>Phone: +91-XXX-XXX-XXXX</li>
                <li>Address: New Delhi, India</li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; 2025 Blue Carbon Registry. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
