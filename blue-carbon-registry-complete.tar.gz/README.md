# 🌊 Blue Carbon Registry - Blockchain MRV System

A comprehensive **Blockchain-Based Blue Carbon Registry and MRV (Monitoring, Reporting, and Verification) System** with integrated **AI Climate Simulator** for transparent carbon credit tokenization and ecosystem restoration tracking.

## 🌍 Live Demo

**Website**: [https://blue-carbon-registry.lindy.site](https://blue-carbon-registry.lindy.site)

## ✨ Features

### 🔗 Blockchain Integration
- **Smart Contracts** for carbon credit tokenization (ERC-721 NFTs)
- **Immutable data storage** on blockchain
- **Transparent verification** and audit trails
- **Automated carbon credit issuance**

### 🌐 AI Climate Simulator
- **3D Interactive Globe** showing real-time climate data
- **AI-powered climate modeling** with time acceleration
- **Dynamic environmental metrics** (CO2, temperature, ocean acidity)
- **Blue carbon impact visualization**

### 👥 Multi-Stakeholder Platform
- **Role-based access** (Admin, NGO, Panchayat, Researcher, Verifier)
- **Community onboarding** workflows
- **Collaborative project management**
- **Permission-based data access**

### 📱 Data Collection System
- **Mobile app integration** for field data
- **GPS coordinates** and location tracking
- **Drone and satellite** imagery support
- **IoT sensor** data integration

### 📊 Analytics & Reporting
- **Real-time dashboards** with metrics
- **NCCR compliance** reporting
- **Carbon credit marketplace** integration
- **Impact visualization** tools

## 🏗️ Tech Stack

### Frontend
- **Next.js 14** with TypeScript
- **React Three Fiber** for 3D graphics
- **Tailwind CSS** + **shadcn/ui** components
- **Framer Motion** for animations

### Backend
- **PostgreSQL** database with Prisma ORM
- **RESTful APIs** for all operations
- **JWT authentication** system
- **File upload** handling

### Blockchain
- **Ethereum-compatible** smart contracts
- **Web3.js** integration
- **MetaMask** wallet connection
- **Carbon credit NFT** tokenization

### AI & 3D
- **Three.js** for 3D globe visualization
- **AI-driven** climate simulation
- **Real-time data** processing
- **Interactive controls**

## 🚀 Getting Started

### Prerequisites
- Node.js 18+ or Bun
- PostgreSQL database
- Git

### Installation

1. **Clone the repository**
```bash
git clone https://github.com/MANMOHAN14/Carbon-EX.git
cd Carbon-EX
```

2. **Install dependencies**
```bash
bun install
# or
npm install
```

3. **Set up environment variables**
```bash
cp .env.example .env
```

Edit `.env` with your configuration:
```env
DATABASE_URL="postgresql://username:password@localhost:5432/blue_carbon_registry"
NEXTAUTH_SECRET="your-secret-key"
NEXTAUTH_URL="http://localhost:3000"
```

4. **Set up the database**
```bash
# Create database
createdb blue_carbon_registry

# Run migrations
npx prisma migrate dev

# Seed demo data
npx prisma db seed
```

5. **Start the development server**
```bash
bun run dev
# or
npm run dev
```

Visit [http://localhost:3000](http://localhost:3000) to see the application.

## 🎮 Demo Accounts

The system comes with pre-seeded demo accounts:

| Role | Email | Password | Description |
|------|-------|----------|-------------|
| **Admin** | admin@bluecarbonregistry.org | admin123 | System administrator |
| **NGO** | ngo@example.org | ngo123 | Coastal Conservation NGO |
| **Panchayat** | panchayat@example.org | panchayat123 | Sundarbans Coastal Panchayat |

## 🌊 Supported Ecosystems

- **🌿 Mangroves** - Coastal forest ecosystems
- **🌊 Seagrass** - Underwater meadows
- **🏞️ Salt Marshes** - Tidal wetlands
- **🦆 Coastal Wetlands** - Brackish ecosystems

## 📈 Project Statistics

- **1,000+** Hectares Monitored
- **50+** Active Projects
- **25,000** Carbon Credits Issued
- **100+** Community Partners

## 🔧 API Endpoints

### Authentication
- `POST /api/auth/login` - User login
- `POST /api/auth/register` - User registration
- `POST /api/auth/logout` - User logout

### Projects
- `GET /api/projects` - List all projects
- `POST /api/projects` - Create new project
- `GET /api/projects/[id]` - Get project details
- `PUT /api/projects/[id]` - Update project

### Data Collection
- `POST /api/data/upload` - Upload field data
- `GET /api/data/entries` - Get data entries
- `POST /api/data/verify` - Verify data entry

### Carbon Credits
- `GET /api/credits` - List carbon credits
- `POST /api/credits/issue` - Issue new credits
- `POST /api/credits/transfer` - Transfer credits

## 🌍 Climate Impact

The integrated AI Climate Simulator demonstrates:

- **Current CO2 levels**: 420+ ppm (Critical)
- **Temperature rise**: 1.2°C above pre-industrial
- **Ocean acidification**: pH 8.1 (declining)
- **Ice cap melting**: 15% loss

### Blue Carbon Solution Impact
- **Potential CO2 reduction**: -126 ppm
- **Ocean health improvement**: +16.2%
- **Ecosystem restoration**: 1M+ hectares potential

## 🤝 Contributing

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🙏 Acknowledgments

- **OpenXAI 2025** - India Accelerator Program
- **Blockseblock Labs** - AI Climate Simulator integration
- **Blue Carbon Community** - Research and methodology
- **Coastal Communities** - Field testing and feedback

## 📞 Contact

- **Email**: manmohan197814@gmail.com
- **GitHub**: [@MANMOHAN14](https://github.com/MANMOHAN14)
- **Project**: [Carbon-EX](https://github.com/MANMOHAN14/Carbon-EX)

---

**Built with ❤️ for climate action and ocean conservation** 🌊🌍
