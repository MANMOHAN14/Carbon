import axios from 'axios'
import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

interface SentinelImagery {
  date: string
  cloudCover: number
  imageUrl: string
  ndviData: number[][]
  vegetationIndex: number
  waterIndex: number
  areaCalculation: number
}

interface NCCRDataset {
  projectId: string
  carbonStock: number
  sequestrationRate: number
  biomass: number
  soilCarbon: number
  methodology: string
  verificationDate: string
  complianceStatus: 'compliant' | 'non-compliant' | 'pending'
}

interface NASAClimateData {
  temperature: number
  precipitation: number
  seaLevelRise: number
  oceanAcidity: number
  co2Concentration: number
  date: string
}

class SatelliteDataIntegration {
  private sentinelApiKey: string
  private nasaApiKey: string
  private nccrApiEndpoint: string

  constructor() {
    this.sentinelApiKey = process.env.SENTINEL_API_KEY || ''
    this.nasaApiKey = process.env.NASA_API_KEY || ''
    this.nccrApiEndpoint = process.env.NCCR_API_ENDPOINT || 'https://api.nccr.gov.in'
  }

  /**
   * Fetch Sentinel-2 satellite imagery for project area monitoring
   */
  async fetchSentinelImagery(
    projectId: string,
    latitude: number,
    longitude: number,
    startDate: string,
    endDate: string
  ): Promise<SentinelImagery[]> {
    try {
      console.log(`🛰️ Fetching Sentinel imagery for project ${projectId}`)

      // Sentinel Hub API call
      const response = await axios.post('https://services.sentinel-hub.com/api/v1/process', {
        input: {
          bounds: {
            bbox: [
              longitude - 0.01, latitude - 0.01,
              longitude + 0.01, latitude + 0.01
            ]
          },
          data: [{
            type: 'sentinel-2-l2a',
            dataFilter: {
              timeRange: {
                from: startDate,
                to: endDate
              },
              maxCloudCoverage: 30
            }
          }]
        },
        output: {
          width: 512,
          height: 512,
          responses: [{
            identifier: 'default',
            format: { type: 'image/jpeg' }
          }]
        },
        evalscript: this.getNDVIEvalScript()
      }, {
        headers: {
          'Authorization': `Bearer ${this.sentinelApiKey}`,
          'Content-Type': 'application/json'
        }
      })

      const imagery: SentinelImagery[] = response.data.map((item: any) => ({
        date: item.date,
        cloudCover: item.cloudCover,
        imageUrl: item.imageUrl,
        ndviData: this.processNDVIData(item.ndviData),
        vegetationIndex: this.calculateVegetationIndex(item.ndviData),
        waterIndex: this.calculateWaterIndex(item.ndviData),
        areaCalculation: this.calculateProjectArea(item.ndviData)
      }))

      // Store imagery data
      await this.storeSatelliteData(projectId, imagery)

      return imagery

    } catch (error) {
      console.error('❌ Error fetching Sentinel imagery:', error)
      return []
    }
  }

  /**
   * Fetch NASA climate data for global context
   */
  async fetchNASAClimateData(
    latitude: number,
    longitude: number,
    startDate: string,
    endDate: string
  ): Promise<NASAClimateData[]> {
    try {
      console.log('🌍 Fetching NASA climate data')

      // NASA POWER API for climate data
      const response = await axios.get('https://power.larc.nasa.gov/api/temporal/daily/point', {
        params: {
          parameters: 'T2M,PRECTOTCORR,PS,RH2M',
          community: 'RE',
          longitude: longitude,
          latitude: latitude,
          start: startDate.replace(/-/g, ''),
          end: endDate.replace(/-/g, ''),
          format: 'JSON'
        },
        headers: {
          'X-API-Key': this.nasaApiKey
        }
      })

      // NASA GISS for CO2 data
      const co2Response = await axios.get('https://climate.nasa.gov/system/internal_resources/details/original/647_Global_Temperature_Data_File.txt')

      const climateData: NASAClimateData[] = Object.keys(response.data.properties.parameter.T2M).map(date => ({
        temperature: response.data.properties.parameter.T2M[date],
        precipitation: response.data.properties.parameter.PRECTOTCORR[date],
        seaLevelRise: this.calculateSeaLevelRise(date),
        oceanAcidity: this.calculateOceanAcidity(date),
        co2Concentration: this.extractCO2Data(co2Response.data, date),
        date: this.formatDate(date)
      }))

      return climateData

    } catch (error) {
      console.error('❌ Error fetching NASA climate data:', error)
      return []
    }
  }

  /**
   * Integrate with NCCR (National Centre for Climate Resilience) datasets
   */
  async fetchNCCRData(projectId: string): Promise<NCCRDataset | null> {
    try {
      console.log(`📊 Fetching NCCR data for project ${projectId}`)

      const response = await axios.get(`${this.nccrApiEndpoint}/projects/${projectId}/carbon-data`, {
        headers: {
          'Authorization': `Bearer ${process.env.NCCR_API_TOKEN}`,
          'Content-Type': 'application/json'
        }
      })

      const nccrData: NCCRDataset = {
        projectId: projectId,
        carbonStock: response.data.carbonStock,
        sequestrationRate: response.data.sequestrationRate,
        biomass: response.data.biomass,
        soilCarbon: response.data.soilCarbon,
        methodology: response.data.methodology,
        verificationDate: response.data.verificationDate,
        complianceStatus: response.data.complianceStatus
      }

      // Store NCCR data
      await this.storeNCCRData(nccrData)

      return nccrData

    } catch (error) {
      console.error('❌ Error fetching NCCR data:', error)
      return null
    }
  }

  /**
   * Automated deforestation detection using satellite imagery
   */
  async detectDeforestation(
    projectId: string,
    latitude: number,
    longitude: number
  ): Promise<{
    deforestationDetected: boolean
    areaLost: number
    severity: 'low' | 'medium' | 'high'
    alertMessage: string
  }> {
    try {
      console.log(`🌳 Detecting deforestation for project ${projectId}`)

      // Get current and historical imagery
      const currentDate = new Date().toISOString().split('T')[0]
      const pastDate = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]

      const currentImagery = await this.fetchSentinelImagery(projectId, latitude, longitude, currentDate, currentDate)
      const pastImagery = await this.fetchSentinelImagery(projectId, latitude, longitude, pastDate, pastDate)

      if (currentImagery.length === 0 || pastImagery.length === 0) {
        return {
          deforestationDetected: false,
          areaLost: 0,
          severity: 'low',
          alertMessage: 'Insufficient imagery data for analysis'
        }
      }

      // Compare vegetation indices
      const currentVegetation = currentImagery[0].vegetationIndex
      const pastVegetation = pastImagery[0].vegetationIndex
      const vegetationLoss = pastVegetation - currentVegetation
      const percentageLoss = (vegetationLoss / pastVegetation) * 100

      const deforestationDetected = percentageLoss > 5 // 5% threshold
      const areaLost = (percentageLoss / 100) * pastImagery[0].areaCalculation

      let severity: 'low' | 'medium' | 'high' = 'low'
      if (percentageLoss > 20) severity = 'high'
      else if (percentageLoss > 10) severity = 'medium'

      const result = {
        deforestationDetected,
        areaLost,
        severity,
        alertMessage: deforestationDetected 
          ? `Deforestation detected: ${percentageLoss.toFixed(2)}% vegetation loss (${areaLost.toFixed(2)} hectares)`
          : 'No significant deforestation detected'
      }

      // Create alert if deforestation detected
      if (deforestationDetected) {
        await prisma.alert.create({
          data: {
            projectId,
            type: 'deforestation',
            message: result.alertMessage,
            severity: severity,
            location: `${latitude},${longitude}`,
            timestamp: new Date()
          }
        })
      }

      return result

    } catch (error) {
      console.error('❌ Error detecting deforestation:', error)
      return {
        deforestationDetected: false,
        areaLost: 0,
        severity: 'low',
        alertMessage: 'Error analyzing deforestation data'
      }
    }
  }

  /**
   * Calculate carbon sequestration using satellite data
   */
  async calculateCarbonSequestration(
    projectId: string,
    imagery: SentinelImagery[]
  ): Promise<{
    totalSequestration: number
    sequestrationRate: number
    biomassEstimate: number
    confidence: number
  }> {
    try {
      if (imagery.length === 0) {
        return { totalSequestration: 0, sequestrationRate: 0, biomassEstimate: 0, confidence: 0 }
      }

      // Calculate biomass from NDVI
      const avgNDVI = imagery.reduce((sum, img) => sum + img.vegetationIndex, 0) / imagery.length
      const biomassEstimate = this.ndviToBiomass(avgNDVI, imagery[0].areaCalculation)

      // Calculate carbon sequestration (biomass * carbon fraction)
      const carbonFraction = 0.47 // 47% of biomass is carbon
      const totalSequestration = biomassEstimate * carbonFraction

      // Calculate sequestration rate (per year)
      const timeSpan = imagery.length > 1 
        ? (new Date(imagery[imagery.length - 1].date).getTime() - new Date(imagery[0].date).getTime()) / (1000 * 60 * 60 * 24 * 365)
        : 1
      const sequestrationRate = totalSequestration / timeSpan

      // Confidence based on data quality
      const avgCloudCover = imagery.reduce((sum, img) => sum + img.cloudCover, 0) / imagery.length
      const confidence = Math.max(0, Math.min(100, 100 - avgCloudCover))

      return {
        totalSequestration,
        sequestrationRate,
        biomassEstimate,
        confidence
      }

    } catch (error) {
      console.error('❌ Error calculating carbon sequestration:', error)
      return { totalSequestration: 0, sequestrationRate: 0, biomassEstimate: 0, confidence: 0 }
    }
  }

  // Helper methods
  private getNDVIEvalScript(): string {
    return `
      //VERSION=3
      function setup() {
        return {
          input: ["B02", "B03", "B04", "B08", "SCL"],
          output: { bands: 4 }
        };
      }
      
      function evaluatePixel(sample) {
        let ndvi = (sample.B08 - sample.B04) / (sample.B08 + sample.B04);
        let ndwi = (sample.B03 - sample.B08) / (sample.B03 + sample.B08);
        
        return [ndvi, ndwi, sample.B04, sample.SCL];
      }
    `
  }

  private processNDVIData(rawData: any): number[][] {
    // Process raw NDVI data into 2D array
    return rawData || []
  }

  private calculateVegetationIndex(ndviData: number[][]): number {
    if (!ndviData || ndviData.length === 0) return 0
    
    let sum = 0
    let count = 0
    
    for (const row of ndviData) {
      for (const value of row) {
        if (value > -1 && value < 1) { // Valid NDVI range
          sum += value
          count++
        }
      }
    }
    
    return count > 0 ? sum / count : 0
  }

  private calculateWaterIndex(ndviData: number[][]): number {
    // Simplified water index calculation
    return 0.3 // Placeholder
  }

  private calculateProjectArea(ndviData: number[][]): number {
    // Calculate area in hectares based on pixel count and resolution
    const pixelSize = 10 // Sentinel-2 pixel size in meters
    const totalPixels = ndviData.length * (ndviData[0]?.length || 0)
    const areaSquareMeters = totalPixels * pixelSize * pixelSize
    return areaSquareMeters / 10000 // Convert to hectares
  }

  private calculateSeaLevelRise(date: string): number {
    // Simplified sea level rise calculation
    return 3.3 // mm/year
  }

  private calculateOceanAcidity(date: string): number {
    // Simplified ocean acidity calculation
    return 8.1 // pH
  }

  private extractCO2Data(data: string, date: string): number {
    // Extract CO2 data from NASA dataset
    return 420 // ppm (placeholder)
  }

  private formatDate(date: string): string {
    return date.replace(/(\d{4})(\d{2})(\d{2})/, '$1-$2-$3')
  }

  private ndviToBiomass(ndvi: number, area: number): number {
    // Convert NDVI to biomass estimate (tons/hectare)
    const biomassPerHectare = Math.max(0, (ndvi + 1) * 50) // Simplified conversion
    return biomassPerHectare * area
  }

  private async storeSatelliteData(projectId: string, imagery: SentinelImagery[]) {
    for (const img of imagery) {
      await prisma.satelliteData.create({
        data: {
          projectId,
          date: new Date(img.date),
          imageUrl: img.imageUrl,
          vegetationIndex: img.vegetationIndex,
          waterIndex: img.waterIndex,
          areaCalculation: img.areaCalculation,
          cloudCover: img.cloudCover,
          ndviData: JSON.stringify(img.ndviData)
        }
      })
    }
  }

  private async storeNCCRData(data: NCCRDataset) {
    await prisma.nccrData.create({
      data: {
        projectId: data.projectId,
        carbonStock: data.carbonStock,
        sequestrationRate: data.sequestrationRate,
        biomass: data.biomass,
        soilCarbon: data.soilCarbon,
        methodology: data.methodology,
        verificationDate: new Date(data.verificationDate),
        complianceStatus: data.complianceStatus
      }
    })
  }
}

// Singleton instance
export const satelliteIntegration = new SatelliteDataIntegration()

export default SatelliteDataIntegration
