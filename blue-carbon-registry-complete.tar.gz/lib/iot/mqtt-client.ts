import mqtt from 'mqtt'
import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

interface IoTSensorData {
  deviceId: string
  projectId: string
  timestamp: string
  sensorType: 'water_quality' | 'air_quality' | 'soil' | 'weather' | 'growth'
  location: {
    latitude: number
    longitude: number
  }
  measurements: {
    [key: string]: number
  }
}

interface WaterQualityData {
  ph: number
  salinity: number
  temperature: number
  dissolvedOxygen: number
  turbidity: number
}

interface AirQualityData {
  co2: number
  humidity: number
  temperature: number
  windSpeed: number
  windDirection: number
}

interface SoilData {
  ph: number
  moisture: number
  temperature: number
  organicMatter: number
  nitrogen: number
  phosphorus: number
  potassium: number
}

interface GrowthData {
  height: number
  diameter: number
  leafCount: number
  healthScore: number
}

class IoTDataIngestion {
  private mqttClient: mqtt.MqttClient | null = null
  private isConnected = false

  constructor() {
    this.initializeMQTT()
  }

  private initializeMQTT() {
    try {
      // Connect to MQTT broker (AWS IoT Core, Azure IoT Hub, or local broker)
      this.mqttClient = mqtt.connect(process.env.MQTT_BROKER_URL || 'mqtt://localhost:1883', {
        clientId: `blue-carbon-registry-${Math.random().toString(16).substr(2, 8)}`,
        username: process.env.MQTT_USERNAME,
        password: process.env.MQTT_PASSWORD,
        clean: true,
        reconnectPeriod: 1000,
      })

      this.mqttClient.on('connect', () => {
        console.log('✅ Connected to MQTT broker')
        this.isConnected = true
        this.subscribeToTopics()
      })

      this.mqttClient.on('message', this.handleIncomingData.bind(this))

      this.mqttClient.on('error', (error) => {
        console.error('❌ MQTT connection error:', error)
        this.isConnected = false
      })

      this.mqttClient.on('close', () => {
        console.log('🔌 MQTT connection closed')
        this.isConnected = false
      })

    } catch (error) {
      console.error('❌ Failed to initialize MQTT:', error)
    }
  }

  private subscribeToTopics() {
    if (!this.mqttClient) return

    const topics = [
      'blue-carbon/+/water-quality',
      'blue-carbon/+/air-quality',
      'blue-carbon/+/soil-data',
      'blue-carbon/+/growth-data',
      'blue-carbon/+/weather',
      'blue-carbon/+/alerts'
    ]

    topics.forEach(topic => {
      this.mqttClient!.subscribe(topic, (err) => {
        if (err) {
          console.error(`❌ Failed to subscribe to ${topic}:`, err)
        } else {
          console.log(`📡 Subscribed to ${topic}`)
        }
      })
    })
  }

  private async handleIncomingData(topic: string, message: Buffer) {
    try {
      const data: IoTSensorData = JSON.parse(message.toString())
      console.log(`📊 Received data from ${topic}:`, data)

      // Validate data
      if (!this.validateSensorData(data)) {
        console.error('❌ Invalid sensor data received')
        return
      }

      // Process based on sensor type
      await this.processSensorData(data)

      // Store in database
      await this.storeSensorData(data)

      // Check for alerts
      await this.checkAlerts(data)

    } catch (error) {
      console.error('❌ Error processing IoT data:', error)
    }
  }

  private validateSensorData(data: IoTSensorData): boolean {
    return !!(
      data.deviceId &&
      data.projectId &&
      data.timestamp &&
      data.sensorType &&
      data.location &&
      data.measurements
    )
  }

  private async processSensorData(data: IoTSensorData) {
    switch (data.sensorType) {
      case 'water_quality':
        await this.processWaterQuality(data)
        break
      case 'air_quality':
        await this.processAirQuality(data)
        break
      case 'soil':
        await this.processSoilData(data)
        break
      case 'growth':
        await this.processGrowthData(data)
        break
      case 'weather':
        await this.processWeatherData(data)
        break
    }
  }

  private async processWaterQuality(data: IoTSensorData) {
    const measurements = data.measurements as WaterQualityData
    
    // Calculate water quality index
    const wqi = this.calculateWaterQualityIndex(measurements)
    
    // Update project metrics
    await this.updateProjectMetrics(data.projectId, {
      waterQualityIndex: wqi,
      lastWaterQualityUpdate: new Date(data.timestamp)
    })
  }

  private async processAirQuality(data: IoTSensorData) {
    const measurements = data.measurements as AirQualityData
    
    // Calculate CO2 sequestration rate
    const sequestrationRate = this.calculateCO2Sequestration(measurements)
    
    // Update project metrics
    await this.updateProjectMetrics(data.projectId, {
      co2SequestrationRate: sequestrationRate,
      lastAirQualityUpdate: new Date(data.timestamp)
    })
  }

  private async processSoilData(data: IoTSensorData) {
    const measurements = data.measurements as SoilData
    
    // Calculate soil health score
    const soilHealthScore = this.calculateSoilHealth(measurements)
    
    // Update project metrics
    await this.updateProjectMetrics(data.projectId, {
      soilHealthScore,
      lastSoilUpdate: new Date(data.timestamp)
    })
  }

  private async processGrowthData(data: IoTSensorData) {
    const measurements = data.measurements as GrowthData
    
    // Calculate growth rate
    const growthRate = await this.calculateGrowthRate(data.projectId, measurements)
    
    // Update project metrics
    await this.updateProjectMetrics(data.projectId, {
      averageGrowthRate: growthRate,
      lastGrowthUpdate: new Date(data.timestamp)
    })
  }

  private async processWeatherData(data: IoTSensorData) {
    // Store weather data for climate modeling
    await this.storeWeatherData(data)
  }

  private calculateWaterQualityIndex(measurements: WaterQualityData): number {
    // Simplified WQI calculation
    const phScore = this.normalizeValue(measurements.ph, 6.5, 8.5, 0, 100)
    const doScore = this.normalizeValue(measurements.dissolvedOxygen, 5, 14, 0, 100)
    const tempScore = this.normalizeValue(measurements.temperature, 20, 30, 0, 100)
    const turbidityScore = this.normalizeValue(measurements.turbidity, 0, 10, 100, 0)
    
    return (phScore + doScore + tempScore + turbidityScore) / 4
  }

  private calculateCO2Sequestration(measurements: AirQualityData): number {
    // Simplified CO2 sequestration calculation based on air quality
    const baseRate = 2.5 // tCO2/hectare/year
    const co2Factor = Math.max(0, (450 - measurements.co2) / 450)
    return baseRate * co2Factor
  }

  private calculateSoilHealth(measurements: SoilData): number {
    // Simplified soil health score
    const phScore = this.normalizeValue(measurements.ph, 6.0, 7.5, 0, 100)
    const moistureScore = this.normalizeValue(measurements.moisture, 30, 70, 0, 100)
    const organicScore = this.normalizeValue(measurements.organicMatter, 2, 8, 0, 100)
    
    return (phScore + moistureScore + organicScore) / 3
  }

  private async calculateGrowthRate(projectId: string, current: GrowthData): Promise<number> {
    // Get previous growth data
    const previousData = await prisma.dataEntry.findFirst({
      where: {
        projectId,
        dataType: 'growth'
      },
      orderBy: {
        timestamp: 'desc'
      },
      skip: 1
    })

    if (!previousData) return 0

    const previous = JSON.parse(previousData.value) as GrowthData
    const timeDiff = Date.now() - previousData.timestamp.getTime()
    const daysDiff = timeDiff / (1000 * 60 * 60 * 24)

    const heightGrowth = (current.height - previous.height) / daysDiff
    return Math.max(0, heightGrowth)
  }

  private normalizeValue(value: number, min: number, max: number, outMin: number, outMax: number): number {
    return Math.max(outMin, Math.min(outMax, 
      ((value - min) / (max - min)) * (outMax - outMin) + outMin
    ))
  }

  private async storeSensorData(data: IoTSensorData) {
    await prisma.dataEntry.create({
      data: {
        projectId: data.projectId,
        dataType: data.sensorType,
        value: JSON.stringify(data.measurements),
        location: `${data.location.latitude},${data.location.longitude}`,
        timestamp: new Date(data.timestamp),
        source: 'iot_sensor',
        deviceId: data.deviceId
      }
    })
  }

  private async updateProjectMetrics(projectId: string, metrics: any) {
    await prisma.project.update({
      where: { id: projectId },
      data: {
        ...metrics,
        updatedAt: new Date()
      }
    })
  }

  private async storeWeatherData(data: IoTSensorData) {
    // Store weather data for climate modeling
    await prisma.weatherData.create({
      data: {
        projectId: data.projectId,
        temperature: data.measurements.temperature,
        humidity: data.measurements.humidity,
        windSpeed: data.measurements.windSpeed,
        windDirection: data.measurements.windDirection,
        timestamp: new Date(data.timestamp),
        location: `${data.location.latitude},${data.location.longitude}`
      }
    })
  }

  private async checkAlerts(data: IoTSensorData) {
    const alerts = []

    // Check for critical values
    if (data.sensorType === 'water_quality') {
      const wq = data.measurements as WaterQualityData
      if (wq.ph < 6.0 || wq.ph > 9.0) {
        alerts.push({
          type: 'water_ph_critical',
          message: `Critical pH level detected: ${wq.ph}`,
          severity: 'high'
        })
      }
      if (wq.dissolvedOxygen < 3.0) {
        alerts.push({
          type: 'low_oxygen',
          message: `Low dissolved oxygen: ${wq.dissolvedOxygen} mg/L`,
          severity: 'high'
        })
      }
    }

    if (data.sensorType === 'air_quality') {
      const aq = data.measurements as AirQualityData
      if (aq.co2 > 500) {
        alerts.push({
          type: 'high_co2',
          message: `High CO2 levels detected: ${aq.co2} ppm`,
          severity: 'medium'
        })
      }
    }

    // Store alerts
    for (const alert of alerts) {
      await prisma.alert.create({
        data: {
          projectId: data.projectId,
          type: alert.type,
          message: alert.message,
          severity: alert.severity,
          deviceId: data.deviceId,
          location: `${data.location.latitude},${data.location.longitude}`,
          timestamp: new Date(data.timestamp)
        }
      })
    }
  }

  public async publishCommand(deviceId: string, command: any) {
    if (!this.mqttClient || !this.isConnected) {
      throw new Error('MQTT client not connected')
    }

    const topic = `blue-carbon/${deviceId}/commands`
    const message = JSON.stringify(command)

    return new Promise((resolve, reject) => {
      this.mqttClient!.publish(topic, message, (err) => {
        if (err) {
          reject(err)
        } else {
          resolve(true)
        }
      })
    })
  }

  public disconnect() {
    if (this.mqttClient) {
      this.mqttClient.end()
    }
  }
}

// Singleton instance
export const iotDataIngestion = new IoTDataIngestion()

export default IoTDataIngestion
