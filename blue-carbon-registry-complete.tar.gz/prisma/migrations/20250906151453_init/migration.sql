-- CreateEnum
CREATE TYPE "public"."UserRole" AS ENUM ('ADMIN', 'NGO', 'PANCHAYAT', 'RESEARCHER', 'VERIFIER');

-- CreateEnum
CREATE TYPE "public"."EcosystemType" AS ENUM ('MANGROVE', 'SEAGRASS', 'SALT_MARSH', 'COASTAL_WETLAND');

-- CreateEnum
CREATE TYPE "public"."ProjectStatus" AS ENUM ('PLANNING', 'ACTIVE', 'MONITORING', 'COMPLETED', 'VERIFIED');

-- CreateEnum
CREATE TYPE "public"."DataType" AS ENUM ('SPECIES_COUNT', 'WATER_QUALITY', 'SOIL_SAMPLE', 'GPS_COORDINATE', 'SATELLITE_IMAGE', 'DRONE_SURVEY', 'GROWTH_MEASUREMENT');

-- CreateEnum
CREATE TYPE "public"."DataSource" AS ENUM ('MOBILE_APP', 'DRONE', 'SATELLITE', 'MANUAL_SURVEY', 'IOT_SENSOR');

-- CreateEnum
CREATE TYPE "public"."CreditStatus" AS ENUM ('PENDING', 'ISSUED', 'TRADED', 'RETIRED');

-- CreateEnum
CREATE TYPE "public"."VerificationStatus" AS ENUM ('PENDING', 'IN_REVIEW', 'APPROVED', 'REJECTED');

-- CreateTable
CREATE TABLE "public"."users" (
    "id" TEXT NOT NULL,
    "email" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "role" "public"."UserRole" NOT NULL,
    "password" TEXT NOT NULL,
    "walletAddress" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "users_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "public"."projects" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "description" TEXT NOT NULL,
    "location" TEXT NOT NULL,
    "coordinates" TEXT NOT NULL,
    "area" DOUBLE PRECISION NOT NULL,
    "ecosystem" "public"."EcosystemType" NOT NULL,
    "status" "public"."ProjectStatus" NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "contractAddress" TEXT,
    "tokenId" TEXT,
    "ownerId" TEXT NOT NULL,

    CONSTRAINT "projects_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "public"."data_entries" (
    "id" TEXT NOT NULL,
    "type" "public"."DataType" NOT NULL,
    "value" TEXT NOT NULL,
    "coordinates" TEXT,
    "timestamp" TIMESTAMP(3) NOT NULL,
    "source" "public"."DataSource" NOT NULL,
    "metadata" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "projectId" TEXT NOT NULL,
    "submitterId" TEXT NOT NULL,

    CONSTRAINT "data_entries_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "public"."carbon_credits" (
    "id" TEXT NOT NULL,
    "amount" DOUBLE PRECISION NOT NULL,
    "price" DOUBLE PRECISION,
    "status" "public"."CreditStatus" NOT NULL,
    "tokenId" TEXT,
    "contractAddress" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "projectId" TEXT NOT NULL,

    CONSTRAINT "carbon_credits_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "public"."verifications" (
    "id" TEXT NOT NULL,
    "status" "public"."VerificationStatus" NOT NULL,
    "notes" TEXT,
    "documents" TEXT,
    "verifiedAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "projectId" TEXT NOT NULL,
    "verifierId" TEXT NOT NULL,

    CONSTRAINT "verifications_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "users_email_key" ON "public"."users"("email");

-- AddForeignKey
ALTER TABLE "public"."projects" ADD CONSTRAINT "projects_ownerId_fkey" FOREIGN KEY ("ownerId") REFERENCES "public"."users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."data_entries" ADD CONSTRAINT "data_entries_projectId_fkey" FOREIGN KEY ("projectId") REFERENCES "public"."projects"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."data_entries" ADD CONSTRAINT "data_entries_submitterId_fkey" FOREIGN KEY ("submitterId") REFERENCES "public"."users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."carbon_credits" ADD CONSTRAINT "carbon_credits_projectId_fkey" FOREIGN KEY ("projectId") REFERENCES "public"."projects"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."verifications" ADD CONSTRAINT "verifications_projectId_fkey" FOREIGN KEY ("projectId") REFERENCES "public"."projects"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "public"."verifications" ADD CONSTRAINT "verifications_verifierId_fkey" FOREIGN KEY ("verifierId") REFERENCES "public"."users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
