import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

async function main() {
  console.log('Seeding database...');

  // Create demo users
  const adminPassword = await bcrypt.hash('admin123', 12);
  const ngoPassword = await bcrypt.hash('ngo123', 12);
  const panchayatPassword = await bcrypt.hash('panchayat123', 12);

  const admin = await prisma.user.upsert({
    where: { email: 'admin@bluecarbonregistry.org' },
    update: {},
    create: {
      email: 'admin@bluecarbonregistry.org',
      name: 'System Administrator',
      password: adminPassword,
      role: 'ADMIN',
      walletAddress: '0x742d35Cc6634C0532925a3b8D4C9db96C4b4d4d4'
    }
  });

  const ngo = await prisma.user.upsert({
    where: { email: 'ngo@example.org' },
    update: {},
    create: {
      email: 'ngo@example.org',
      name: 'Coastal Conservation NGO',
      password: ngoPassword,
      role: 'NGO',
      walletAddress: '0x8ba1f109551bD432803012645Hac136c30C6d4d4'
    }
  });

  const panchayat = await prisma.user.upsert({
    where: { email: 'panchayat@example.org' },
    update: {},
    create: {
      email: 'panchayat@example.org',
      name: 'Sundarbans Coastal Panchayat',
      password: panchayatPassword,
      role: 'PANCHAYAT',
      walletAddress: '0x9ca2f209551bD432803012645Hac136c30C7e5e5'
    }
  });

  // Create demo projects
  const project1 = await prisma.project.create({
    data: {
      name: 'Sundarbans Mangrove Restoration',
      description: 'Large-scale mangrove restoration project in the Sundarbans delta region focusing on Rhizophora and Avicennia species plantation.',
      location: 'Sundarbans, West Bengal, India',
      coordinates: JSON.stringify({ lat: 21.9497, lng: 88.1943 }),
      area: 250.5,
      ecosystem: 'MANGROVE',
      status: 'ACTIVE',
      ownerId: ngo.id,
      contractAddress: '0x1234567890123456789012345678901234567890',
      tokenId: '1'
    }
  });

  const project2 = await prisma.project.create({
    data: {
      name: 'Kerala Seagrass Conservation',
      description: 'Seagrass meadow restoration and protection project along the Kerala coast.',
      location: 'Kochi, Kerala, India',
      coordinates: JSON.stringify({ lat: 9.9312, lng: 76.2673 }),
      area: 125.0,
      ecosystem: 'SEAGRASS',
      status: 'MONITORING',
      ownerId: panchayat.id
    }
  });

  // Create demo data entries
  await prisma.dataEntry.createMany({
    data: [
      {
        projectId: project1.id,
        type: 'SPECIES_COUNT',
        value: JSON.stringify({ species: 'Rhizophora mucronata', count: 1250, surveyArea: '10 hectares' }),
        coordinates: JSON.stringify({ lat: 21.9500, lng: 88.1950 }),
        source: 'MOBILE_APP',
        timestamp: new Date('2024-08-15'),
        submitterId: ngo.id,
        metadata: JSON.stringify({ weather: 'sunny', temperature: 28, observer: 'Field Team A' })
      },
      {
        projectId: project1.id,
        type: 'WATER_QUALITY',
        value: JSON.stringify({ pH: 7.8, salinity: 15, dissolvedOxygen: 6.2, turbidity: 12 }),
        coordinates: JSON.stringify({ lat: 21.9485, lng: 88.1935 }),
        source: 'IOT_SENSOR',
        timestamp: new Date('2024-08-20'),
        submitterId: ngo.id
      },
      {
        projectId: project2.id,
        type: 'GROWTH_MEASUREMENT',
        value: JSON.stringify({ averageHeight: 45, canopyCover: 75, biomass: 12.5 }),
        coordinates: JSON.stringify({ lat: 9.9320, lng: 76.2680 }),
        source: 'DRONE',
        timestamp: new Date('2024-08-25'),
        submitterId: panchayat.id
      }
    ]
  });

  // Create demo carbon credits
  await prisma.carbonCredit.createMany({
    data: [
      {
        projectId: project1.id,
        amount: 125.5,
        price: 35.0,
        status: 'ISSUED',
        tokenId: '1',
        contractAddress: '0x1234567890123456789012345678901234567890'
      },
      {
        projectId: project1.id,
        amount: 89.2,
        price: 32.0,
        status: 'PENDING',
        tokenId: '2',
        contractAddress: '0x1234567890123456789012345678901234567890'
      },
      {
        projectId: project2.id,
        amount: 67.8,
        price: 40.0,
        status: 'ISSUED',
        tokenId: '3',
        contractAddress: '0x1234567890123456789012345678901234567890'
      }
    ]
  });

  // Create demo verifications
  await prisma.verification.createMany({
    data: [
      {
        projectId: project1.id,
        status: 'APPROVED',
        notes: 'Project meets all MRV standards. Satellite imagery confirms restoration progress.',
        verifiedAt: new Date('2024-08-30'),
        verifierId: admin.id
      },
      {
        projectId: project2.id,
        status: 'IN_REVIEW',
        notes: 'Initial review completed. Awaiting additional documentation.',
        verifierId: admin.id
      }
    ]
  });

  console.log('Database seeded successfully!');
  console.log('Demo accounts created:');
  console.log('- Admin: admin@bluecarbonregistry.org / admin123');
  console.log('- NGO: ngo@example.org / ngo123');
  console.log('- Panchayat: panchayat@example.org / panchayat123');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
