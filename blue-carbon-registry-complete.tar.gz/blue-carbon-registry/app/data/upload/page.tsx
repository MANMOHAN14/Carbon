"use client";

import { useState, useEffect } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Leaf, ArrowLeft, Upload, Smartphone, Drone, Satellite } from 'lucide-react';
import Link from 'next/link';
import { toast } from 'sonner';

export default function DataUploadPage() {
  const [formData, setFormData] = useState({
    projectId: '',
    type: '',
    value: '',
    coordinates: '',
    source: '',
    metadata: ''
  });
  const [projects, setProjects] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const router = useRouter();
  const searchParams = useSearchParams();

  useEffect(() => {
    const token = localStorage.getItem('token');
    if (!token) {
      router.push('/auth/login');
      return;
    }

    // Pre-select project if provided in URL
    const projectId = searchParams.get('projectId');
    if (projectId) {
      setFormData(prev => ({ ...prev, projectId }));
    }

    fetchProjects(token);
  }, [router, searchParams]);

  const fetchProjects = async (token: string) => {
    try {
      const response = await fetch('/api/projects', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });

      if (response.ok) {
        const data = await response.json();
        setProjects(data.projects);
      }
    } catch (error) {
      console.error('Failed to fetch projects:', error);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.projectId || !formData.type || !formData.value || !formData.source) {
      toast.error('Please fill in all required fields');
      return;
    }

    const token = localStorage.getItem('token');
    if (!token) {
      router.push('/auth/login');
      return;
    }

    setIsLoading(true);

    try {
      let parsedValue;
      try {
        parsedValue = JSON.parse(formData.value);
      } catch {
        parsedValue = formData.value;
      }

      let parsedCoordinates = null;
      if (formData.coordinates) {
        try {
          parsedCoordinates = JSON.parse(formData.coordinates);
        } catch {
          // Try to parse as "lat,lng" format
          const coords = formData.coordinates.split(',');
          if (coords.length === 2) {
            parsedCoordinates = {
              lat: parseFloat(coords[0].trim()),
              lng: parseFloat(coords[1].trim())
            };
          }
        }
      }

      const response = await fetch('/api/data', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          projectId: formData.projectId,
          type: formData.type,
          value: parsedValue,
          coordinates: parsedCoordinates,
          source: formData.source,
          metadata: formData.metadata ? JSON.parse(formData.metadata) : null
        }),
      });

      const data = await response.json();

      if (response.ok) {
        toast.success('Data uploaded successfully!');
        router.push('/dashboard');
      } else {
        toast.error(data.error || 'Failed to upload data');
      }
    } catch (error) {
      toast.error('Network error. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const getDataTypeDescription = (type: string) => {
    switch (type) {
      case 'SPECIES_COUNT': return 'Number of species or individual organisms observed';
      case 'WATER_QUALITY': return 'pH, salinity, dissolved oxygen, turbidity measurements';
      case 'SOIL_SAMPLE': return 'Soil composition, carbon content, nutrient levels';
      case 'GPS_COORDINATE': return 'Precise location data for monitoring points';
      case 'SATELLITE_IMAGE': return 'Satellite imagery URLs or analysis results';
      case 'DRONE_SURVEY': return 'Aerial survey data, images, or measurements';
      case 'GROWTH_MEASUREMENT': return 'Plant height, canopy cover, biomass measurements';
      default: return '';
    }
  };

  const getSourceIcon = (source: string) => {
    switch (source) {
      case 'MOBILE_APP': return <Smartphone className="h-4 w-4" />;
      case 'DRONE': return <Drone className="h-4 w-4" />;
      case 'SATELLITE': return <Satellite className="h-4 w-4" />;
      default: return <Upload className="h-4 w-4" />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Navigation */}
      <nav className="bg-white border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-2">
              <Leaf className="h-8 w-8 text-green-600" />
              <span className="text-xl font-bold text-gray-900">Blue Carbon Registry</span>
            </div>
            <Link href="/dashboard">
              <Button variant="ghost">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to Dashboard
              </Button>
            </Link>
          </div>
        </div>
      </nav>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Upload Monitoring Data</h1>
          <p className="text-gray-600 mt-2">Add field data, measurements, and observations to your project</p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Data Entry Form</CardTitle>
            <CardDescription>
              Upload monitoring data from field surveys, drones, or sensors
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="projectId">Project *</Label>
                  <Select value={formData.projectId} onValueChange={(value) => handleInputChange('projectId', value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select project" />
                    </SelectTrigger>
                    <SelectContent>
                      {projects.map((project: any) => (
                        <SelectItem key={project.id} value={project.id}>
                          {project.name} - {project.location}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="type">Data Type *</Label>
                  <Select value={formData.type} onValueChange={(value) => handleInputChange('type', value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select data type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="SPECIES_COUNT">Species Count</SelectItem>
                      <SelectItem value="WATER_QUALITY">Water Quality</SelectItem>
                      <SelectItem value="SOIL_SAMPLE">Soil Sample</SelectItem>
                      <SelectItem value="GPS_COORDINATE">GPS Coordinate</SelectItem>
                      <SelectItem value="SATELLITE_IMAGE">Satellite Image</SelectItem>
                      <SelectItem value="DRONE_SURVEY">Drone Survey</SelectItem>
                      <SelectItem value="GROWTH_MEASUREMENT">Growth Measurement</SelectItem>
                    </SelectContent>
                  </Select>
                  {formData.type && (
                    <p className="text-sm text-gray-600">{getDataTypeDescription(formData.type)}</p>
                  )}
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="value">Data Value *</Label>
                <Textarea
                  id="value"
                  placeholder="Enter data value (JSON format for complex data, e.g., {'count': 25, 'species': 'Rhizophora mucronata'})"
                  value={formData.value}
                  onChange={(e) => handleInputChange('value', e.target.value)}
                  rows={3}
                  required
                />
                <p className="text-sm text-gray-600">
                  For simple values, enter directly. For complex data, use JSON format.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="coordinates">GPS Coordinates (Optional)</Label>
                  <Input
                    id="coordinates"
                    placeholder="21.9497,88.1943 or {'lat': 21.9497, 'lng': 88.1943}"
                    value={formData.coordinates}
                    onChange={(e) => handleInputChange('coordinates', e.target.value)}
                  />
                  <p className="text-sm text-gray-600">
                    Format: lat,lng or JSON object
                  </p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="source">Data Source *</Label>
                  <Select value={formData.source} onValueChange={(value) => handleInputChange('source', value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select data source" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="MOBILE_APP">
                        <div className="flex items-center space-x-2">
                          <Smartphone className="h-4 w-4" />
                          <span>Mobile App</span>
                        </div>
                      </SelectItem>
                      <SelectItem value="DRONE">
                        <div className="flex items-center space-x-2">
                          <Drone className="h-4 w-4" />
                          <span>Drone Survey</span>
                        </div>
                      </SelectItem>
                      <SelectItem value="SATELLITE">
                        <div className="flex items-center space-x-2">
                          <Satellite className="h-4 w-4" />
                          <span>Satellite</span>
                        </div>
                      </SelectItem>
                      <SelectItem value="MANUAL_SURVEY">Manual Survey</SelectItem>
                      <SelectItem value="IOT_SENSOR">IoT Sensor</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="metadata">Additional Metadata (Optional)</Label>
                <Textarea
                  id="metadata"
                  placeholder="Additional information in JSON format, e.g., {'weather': 'sunny', 'temperature': 28, 'observer': 'John Doe'}"
                  value={formData.metadata}
                  onChange={(e) => handleInputChange('metadata', e.target.value)}
                  rows={2}
                />
                <p className="text-sm text-gray-600">
                  Optional metadata like weather conditions, observer name, equipment used, etc.
                </p>
              </div>

              <div className="bg-green-50 p-4 rounded-lg">
                <div className="flex items-start space-x-2">
                  <Upload className="h-5 w-5 text-green-600 mt-0.5" />
                  <div>
                    <h4 className="font-medium text-green-900">Data Quality Guidelines</h4>
                    <ul className="text-sm text-green-700 mt-1 space-y-1">
                      <li>• Ensure GPS coordinates are accurate for location-based data</li>
                      <li>• Use consistent units and formats for measurements</li>
                      <li>• Include relevant metadata for better data interpretation</li>
                      <li>• Verify data accuracy before submission</li>
                    </ul>
                  </div>
                </div>
              </div>

              <div className="flex justify-end space-x-4">
                <Link href="/dashboard">
                  <Button variant="outline">Cancel</Button>
                </Link>
                <Button 
                  type="submit" 
                  className="bg-green-600 hover:bg-green-700"
                  disabled={isLoading}
                >
                  {isLoading ? 'Uploading...' : 'Upload Data'}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
