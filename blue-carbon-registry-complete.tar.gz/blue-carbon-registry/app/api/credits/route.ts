import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import jwt from 'jsonwebtoken';

function verifyToken(request: NextRequest) {
  const authHeader = request.headers.get('authorization');
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    throw new Error('No token provided');
  }
  
  const token = authHeader.substring(7);
  return jwt.verify(token, process.env.JWT_SECRET || 'fallback-secret') as any;
}

export async function POST(request: NextRequest) {
  try {
    const decoded = verifyToken(request);
    const { projectId, amount, price, tokenId, contractAddress } = await request.json();

    if (!projectId || !amount) {
      return NextResponse.json(
        { error: 'ProjectId and amount are required' },
        { status: 400 }
      );
    }

    // Verify user has admin or verifier role
    if (!['ADMIN', 'VERIFIER'].includes(decoded.role)) {
      return NextResponse.json(
        { error: 'Insufficient permissions' },
        { status: 403 }
      );
    }

    // Verify project exists
    const project = await prisma.project.findUnique({
      where: { id: projectId }
    });

    if (!project) {
      return NextResponse.json(
        { error: 'Project not found' },
        { status: 404 }
      );
    }

    const carbonCredit = await prisma.carbonCredit.create({
      data: {
        projectId,
        amount: parseFloat(amount),
        price: price ? parseFloat(price) : null,
        status: 'PENDING',
        tokenId,
        contractAddress
      },
      include: {
        project: {
          select: { name: true, location: true, ecosystem: true }
        }
      }
    });

    return NextResponse.json({ carbonCredit }, { status: 201 });
  } catch (error) {
    console.error('Create carbon credit error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

export async function GET(request: NextRequest) {
  try {
    const decoded = verifyToken(request);
    const { searchParams } = new URL(request.url);
    const projectId = searchParams.get('projectId');
    const status = searchParams.get('status');

    let whereClause: any = {};
    if (projectId) whereClause.projectId = projectId;
    if (status) whereClause.status = status;

    const carbonCredits = await prisma.carbonCredit.findMany({
      where: whereClause,
      include: {
        project: {
          select: { name: true, location: true, ecosystem: true, owner: { select: { name: true } } }
        }
      },
      orderBy: { createdAt: 'desc' }
    });

    return NextResponse.json({ carbonCredits });
  } catch (error) {
    console.error('Get carbon credits error:', error);
    return NextResponse.json(
      { error: 'Unauthorized' },
      { status: 401 }
    );
  }
}

export async function PATCH(request: NextRequest) {
  try {
    const decoded = verifyToken(request);
    const { id, status, tokenId, contractAddress } = await request.json();

    if (!id || !status) {
      return NextResponse.json(
        { error: 'Credit ID and status are required' },
        { status: 400 }
      );
    }

    // Verify user has admin or verifier role
    if (!['ADMIN', 'VERIFIER'].includes(decoded.role)) {
      return NextResponse.json(
        { error: 'Insufficient permissions' },
        { status: 403 }
      );
    }

    const carbonCredit = await prisma.carbonCredit.update({
      where: { id },
      data: {
        status,
        tokenId: tokenId || undefined,
        contractAddress: contractAddress || undefined
      },
      include: {
        project: {
          select: { name: true, location: true, ecosystem: true }
        }
      }
    });

    return NextResponse.json({ carbonCredit });
  } catch (error) {
    console.error('Update carbon credit error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
