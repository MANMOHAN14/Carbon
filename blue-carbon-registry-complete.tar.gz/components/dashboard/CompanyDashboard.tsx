"use client"

import React, { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Progress } from '@/components/ui/progress'
import { 
  Building2, 
  TrendingUp, 
  Leaf, 
  DollarSign, 
  Users, 
  MapPin,
  Calendar,
  Award,
  Target,
  BarChart3,
  PieChart,
  Download,
  Share2,
  AlertCircle,
  CheckCircle,
  Clock
} from 'lucide-react'
import { motion } from 'framer-motion'

interface CompanyMetrics {
  totalProjects: number
  activeProjects: number
  completedProjects: number
  totalCarbonCredits: number
  totalRevenue: number
  totalArea: number
  ecosystemTypes: { [key: string]: number }
  monthlyGrowth: number
  complianceScore: number
  esgRating: string
}

interface Project {
  id: string
  name: string
  ecosystem: string
  area: number
  status: 'active' | 'completed' | 'pending'
  carbonCredits: number
  revenue: number
  location: string
  startDate: Date
  complianceScore: number
}

interface CompanyDashboardProps {
  companyId?: string
}

export function CompanyDashboard({ companyId }: CompanyDashboardProps) {
  const [metrics, setMetrics] = useState<CompanyMetrics | null>(null)
  const [projects, setProjects] = useState<Project[]>([])
  const [loading, setLoading] = useState(true)
  const [activeTab, setActiveTab] = useState('overview')
  const [timeRange, setTimeRange] = useState('12m')

  useEffect(() => {
    fetchCompanyData()
  }, [companyId, timeRange])

  const fetchCompanyData = async () => {
    try {
      const response = await fetch(`/api/company/dashboard${companyId ? `?companyId=${companyId}` : ''}`)
      const data = await response.json()
      setMetrics(data.metrics)
      setProjects(data.projects)
    } catch (error) {
      console.error('Error fetching company data:', error)
      // Use mock data for demo
      setMetrics(mockMetrics)
      setProjects(mockProjects)
    } finally {
      setLoading(false)
    }
  }

  const mockMetrics: CompanyMetrics = {
    totalProjects: 12,
    activeProjects: 8,
    completedProjects: 4,
    totalCarbonCredits: 15420,
    totalRevenue: 542800,
    totalArea: 2340,
    ecosystemTypes: {
      'Mangroves': 45,
      'Seagrass': 30,
      'Salt Marshes': 20,
      'Coastal Wetlands': 5
    },
    monthlyGrowth: 12.5,
    complianceScore: 94.2,
    esgRating: 'A+'
  }

  const mockProjects: Project[] = [
    {
      id: '1',
      name: 'Sundarbans Mangrove Restoration',
      ecosystem: 'Mangroves',
      area: 450,
      status: 'active',
      carbonCredits: 3200,
      revenue: 128000,
      location: 'West Bengal, India',
      startDate: new Date('2024-03-15'),
      complianceScore: 96.5
    },
    {
      id: '2',
      name: 'Kerala Backwater Seagrass',
      ecosystem: 'Seagrass',
      area: 280,
      status: 'active',
      carbonCredits: 1890,
      revenue: 75600,
      location: 'Kerala, India',
      startDate: new Date('2024-06-20'),
      complianceScore: 92.1
    },
    {
      id: '3',
      name: 'Gujarat Salt Marsh Conservation',
      ecosystem: 'Salt Marshes',
      area: 320,
      status: 'completed',
      carbonCredits: 2150,
      revenue: 86000,
      location: 'Gujarat, India',
      startDate: new Date('2023-11-10'),
      complianceScore: 98.3
    },
    {
      id: '4',
      name: 'Tamil Nadu Coastal Wetlands',
      ecosystem: 'Coastal Wetlands',
      area: 180,
      status: 'pending',
      carbonCredits: 0,
      revenue: 0,
      location: 'Tamil Nadu, India',
      startDate: new Date('2025-01-15'),
      complianceScore: 0
    }
  ]

  const displayMetrics = metrics || mockMetrics
  const displayProjects = projects.length > 0 ? projects : mockProjects

  if (loading) {
    return (
      <Card className="w-full">
        <CardContent className="p-8">
          <div className="animate-pulse space-y-4">
            <div className="h-8 bg-gray-200 rounded w-1/3"></div>
            <div className="grid grid-cols-4 gap-4">
              {[1, 2, 3, 4].map(i => (
                <div key={i} className="h-24 bg-gray-200 rounded"></div>
              ))}
            </div>
            <div className="h-64 bg-gray-200 rounded"></div>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="w-full space-y-6">
      {/* Header */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Building2 className="w-6 h-6 text-blue-600" />
              <CardTitle className="text-xl">Company Dashboard</CardTitle>
              <Badge variant="outline" className="bg-green-50 text-green-700">
                ESG Rating: {displayMetrics.esgRating}
              </Badge>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" size="sm">
                <Download className="w-4 h-4 mr-2" />
                Export Report
              </Button>
              <Button variant="outline" size="sm">
                <Share2 className="w-4 h-4 mr-2" />
                Share Dashboard
              </Button>
            </div>
          </div>
        </CardHeader>
      </Card>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="border-blue-200 bg-blue-50">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-blue-500 rounded-lg">
                <Target className="w-5 h-5 text-white" />
              </div>
              <div>
                <p className="text-2xl font-bold text-blue-600">{displayMetrics.totalProjects}</p>
                <p className="text-sm text-blue-600">Total Projects</p>
                <p className="text-xs text-blue-500">{displayMetrics.activeProjects} active</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-green-200 bg-green-50">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-green-500 rounded-lg">
                <Leaf className="w-5 h-5 text-white" />
              </div>
              <div>
                <p className="text-2xl font-bold text-green-600">{displayMetrics.totalCarbonCredits.toLocaleString()}</p>
                <p className="text-sm text-green-600">Carbon Credits</p>
                <p className="text-xs text-green-500">+{displayMetrics.monthlyGrowth}% this month</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-purple-200 bg-purple-50">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-purple-500 rounded-lg">
                <DollarSign className="w-5 h-5 text-white" />
              </div>
              <div>
                <p className="text-2xl font-bold text-purple-600">${displayMetrics.totalRevenue.toLocaleString()}</p>
                <p className="text-sm text-purple-600">Total Revenue</p>
                <p className="text-xs text-purple-500">USD from credits</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-orange-200 bg-orange-50">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-orange-500 rounded-lg">
                <MapPin className="w-5 h-5 text-white" />
              </div>
              <div>
                <p className="text-2xl font-bold text-orange-600">{displayMetrics.totalArea.toLocaleString()}</p>
                <p className="text-sm text-orange-600">Hectares Restored</p>
                <p className="text-xs text-orange-500">Across all projects</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Dashboard */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="projects">Projects</TabsTrigger>
          <TabsTrigger value="performance">Performance</TabsTrigger>
          <TabsTrigger value="compliance">Compliance</TabsTrigger>
          <TabsTrigger value="esg">ESG Reporting</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Ecosystem Distribution */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <PieChart className="w-5 h-5" />
                  Ecosystem Distribution
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {Object.entries(displayMetrics.ecosystemTypes).map(([ecosystem, percentage]) => (
                    <div key={ecosystem} className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-sm font-medium">{ecosystem}</span>
                        <span className="text-sm text-gray-500">{percentage}%</span>
                      </div>
                      <Progress value={percentage} className="h-2" />
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Performance Metrics */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BarChart3 className="w-5 h-5" />
                  Performance Metrics
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
                    <div className="flex items-center gap-2">
                      <CheckCircle className="w-5 h-5 text-green-600" />
                      <span className="font-medium">Compliance Score</span>
                    </div>
                    <span className="text-lg font-bold text-green-600">
                      {displayMetrics.complianceScore}%
                    </span>
                  </div>
                  
                  <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
                    <div className="flex items-center gap-2">
                      <TrendingUp className="w-5 h-5 text-blue-600" />
                      <span className="font-medium">Monthly Growth</span>
                    </div>
                    <span className="text-lg font-bold text-blue-600">
                      +{displayMetrics.monthlyGrowth}%
                    </span>
                  </div>
                  
                  <div className="flex items-center justify-between p-3 bg-purple-50 rounded-lg">
                    <div className="flex items-center gap-2">
                      <Award className="w-5 h-5 text-purple-600" />
                      <span className="font-medium">ESG Rating</span>
                    </div>
                    <span className="text-lg font-bold text-purple-600">
                      {displayMetrics.esgRating}
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Recent Activity */}
          <Card>
            <CardHeader>
              <CardTitle>Recent Project Activity</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {displayProjects.slice(0, 3).map((project) => (
                  <motion.div
                    key={project.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="flex items-center justify-between p-4 border rounded-lg"
                  >
                    <div className="flex items-center gap-4">
                      <div className="p-2 bg-blue-100 rounded-lg">
                        <Leaf className="w-5 h-5 text-blue-600" />
                      </div>
                      <div>
                        <h4 className="font-semibold">{project.name}</h4>
                        <p className="text-sm text-gray-600">{project.ecosystem} • {project.area} hectares</p>
                        <p className="text-xs text-gray-500">{project.location}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <Badge variant={
                        project.status === 'active' ? 'default' :
                        project.status === 'completed' ? 'secondary' : 'outline'
                      }>
                        {project.status}
                      </Badge>
                      <p className="text-sm font-medium mt-1">{project.carbonCredits} credits</p>
                    </div>
                  </motion.div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="projects" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>All Projects</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {displayProjects.map((project) => (
                  <div key={project.id} className="p-4 border rounded-lg">
                    <div className="flex items-center justify-between mb-3">
                      <div>
                        <h4 className="font-semibold text-lg">{project.name}</h4>
                        <p className="text-gray-600">{project.location}</p>
                      </div>
                      <Badge variant={
                        project.status === 'active' ? 'default' :
                        project.status === 'completed' ? 'secondary' : 'outline'
                      }>
                        {project.status}
                      </Badge>
                    </div>
                    
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-3">
                      <div>
                        <p className="text-sm text-gray-500">Ecosystem</p>
                        <p className="font-medium">{project.ecosystem}</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-500">Area</p>
                        <p className="font-medium">{project.area} ha</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-500">Carbon Credits</p>
                        <p className="font-medium">{project.carbonCredits.toLocaleString()}</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-500">Revenue</p>
                        <p className="font-medium">${project.revenue.toLocaleString()}</p>
                      </div>
                    </div>
                    
                    {project.status !== 'pending' && (
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span>Compliance Score</span>
                          <span>{project.complianceScore}%</span>
                        </div>
                        <Progress value={project.complianceScore} className="h-2" />
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="performance" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Carbon Credit Generation</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="text-center">
                    <p className="text-3xl font-bold text-green-600">
                      {displayMetrics.totalCarbonCredits.toLocaleString()}
                    </p>
                    <p className="text-gray-600">Total Credits Generated</p>
                  </div>
                  <div className="grid grid-cols-2 gap-4 text-center">
                    <div className="p-3 bg-blue-50 rounded-lg">
                      <p className="text-xl font-bold text-blue-600">1,250</p>
                      <p className="text-sm text-blue-600">This Month</p>
                    </div>
                    <div className="p-3 bg-green-50 rounded-lg">
                      <p className="text-xl font-bold text-green-600">890</p>
                      <p className="text-sm text-green-600">Last Month</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Revenue Analytics</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="text-center">
                    <p className="text-3xl font-bold text-purple-600">
                      ${displayMetrics.totalRevenue.toLocaleString()}
                    </p>
                    <p className="text-gray-600">Total Revenue</p>
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm">Average Price per Credit</span>
                      <span className="text-sm font-medium">$35.20</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm">Monthly Revenue Growth</span>
                      <span className="text-sm font-medium text-green-600">+12.5%</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="compliance" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Compliance Overview</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="text-center">
                  <p className="text-4xl font-bold text-green-600">{displayMetrics.complianceScore}%</p>
                  <p className="text-gray-600">Overall Compliance Score</p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="p-4 border rounded-lg">
                    <div className="flex items-center gap-2 mb-2">
                      <CheckCircle className="w-5 h-5 text-green-600" />
                      <span className="font-medium">NCCR Compliance</span>
                    </div>
                    <p className="text-2xl font-bold text-green-600">98%</p>
                    <p className="text-sm text-gray-600">All requirements met</p>
                  </div>

                  <div className="p-4 border rounded-lg">
                    <div className="flex items-center gap-2 mb-2">
                      <CheckCircle className="w-5 h-5 text-blue-600" />
                      <span className="font-medium">Data Quality</span>
                    </div>
                    <p className="text-2xl font-bold text-blue-600">95%</p>
                    <p className="text-sm text-gray-600">High quality data</p>
                  </div>

                  <div className="p-4 border rounded-lg">
                    <div className="flex items-center gap-2 mb-2">
                      <Clock className="w-5 h-5 text-orange-600" />
                      <span className="font-medium">Reporting</span>
                    </div>
                    <p className="text-2xl font-bold text-orange-600">89%</p>
                    <p className="text-sm text-gray-600">On-time submissions</p>
                  </div>
                </div>

                <div className="space-y-3">
                  <h4 className="font-semibold">Recent Compliance Activities</h4>
                  <div className="space-y-2">
                    <div className="flex items-center gap-3 p-3 bg-green-50 rounded-lg">
                      <CheckCircle className="w-5 h-5 text-green-600" />
                      <div>
                        <p className="font-medium">Q3 2024 Report Submitted</p>
                        <p className="text-sm text-gray-600">Submitted 2 days early</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3 p-3 bg-blue-50 rounded-lg">
                      <CheckCircle className="w-5 h-5 text-blue-600" />
                      <div>
                        <p className="font-medium">Third-party Verification Complete</p>
                        <p className="text-sm text-gray-600">All projects verified</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="esg" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>ESG Performance Report</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="text-center">
                  <p className="text-4xl font-bold text-purple-600">{displayMetrics.esgRating}</p>
                  <p className="text-gray-600">ESG Rating</p>
                  <p className="text-sm text-gray-500">Top 5% of blue carbon companies</p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="p-4 border rounded-lg">
                    <h4 className="font-semibold text-green-600 mb-2">Environmental</h4>
                    <p className="text-2xl font-bold">A+</p>
                    <ul className="text-sm text-gray-600 mt-2 space-y-1">
                      <li>• Carbon sequestration: 15,420 tCO2</li>
                      <li>• Biodiversity restoration: 2,340 ha</li>
                      <li>• Water quality improvement</li>
                    </ul>
                  </div>

                  <div className="p-4 border rounded-lg">
                    <h4 className="font-semibold text-blue-600 mb-2">Social</h4>
                    <p className="text-2xl font-bold">A</p>
                    <ul className="text-sm text-gray-600 mt-2 space-y-1">
                      <li>• Community engagement: 850 people</li>
                      <li>• Local employment: 120 jobs</li>
                      <li>• Capacity building programs</li>
                    </ul>
                  </div>

                  <div className="p-4 border rounded-lg">
                    <h4 className="font-semibold text-purple-600 mb-2">Governance</h4>
                    <p className="text-2xl font-bold">A+</p>
                    <ul className="text-sm text-gray-600 mt-2 space-y-1">
                      <li>• Transparent reporting</li>
                      <li>• Blockchain verification</li>
                      <li>• Stakeholder engagement</li>
                    </ul>
                  </div>
                </div>

                <div className="p-4 bg-gradient-to-r from-green-50 to-blue-50 rounded-lg">
                  <h4 className="font-semibold mb-2">Impact Summary</h4>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
                    <div>
                      <p className="text-xl font-bold text-green-600">15,420</p>
                      <p className="text-sm text-gray-600">tCO2 Sequestered</p>
                    </div>
                    <div>
                      <p className="text-xl font-bold text-blue-600">2,340</p>
                      <p className="text-sm text-gray-600">Hectares Restored</p>
                    </div>
                    <div>
                      <p className="text-xl font-bold text-purple-600">850</p>
                      <p className="text-sm text-gray-600">People Engaged</p>
                    </div>
                    <div>
                      <p className="text-xl font-bold text-orange-600">120</p>
                      <p className="text-sm text-gray-600">Jobs Created</p>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

export default CompanyDashboard
