"use client"

import React, { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Award, Download, Share2, MapPin, Calendar, Leaf } from 'lucide-react'

interface CertificateMetadata {
  tokenId: string
  projectName: string
  location: string
  carbonCredits: number
  issuanceDate: string
  verificationDate: string
  ecosystem: string
  area: number
  methodology: string
  vintage: string
  status: 'active' | 'retired' | 'pending'
  ipfsHash: string
  blockchainTxHash: string
}

interface CertificateDisplayProps {
  tokenId: string
  metadata?: CertificateMetadata
}

export function CertificateDisplay({ tokenId, metadata }: CertificateDisplayProps) {
  const [certificateData, setCertificateData] = useState<CertificateMetadata | null>(metadata || null)
  const [loading, setLoading] = useState(!metadata)

  useEffect(() => {
    if (!metadata) {
      fetchCertificateMetadata()
    }
  }, [tokenId, metadata])

  const fetchCertificateMetadata = async () => {
    try {
      setLoading(true)
      const response = await fetch(`/api/certificates/${tokenId}`)
      const data = await response.json()
      setCertificateData(data)
    } catch (error) {
      console.error('Error fetching certificate metadata:', error)
    } finally {
      setLoading(false)
    }
  }

  const downloadCertificate = () => {
    // Generate PDF certificate
    window.open(`/api/certificates/${tokenId}/pdf`, '_blank')
  }

  const shareCertificate = () => {
    navigator.share({
      title: `Blue Carbon Certificate #${tokenId}`,
      text: `Verified carbon credit certificate for ${certificateData?.carbonCredits} tCO2`,
      url: window.location.href
    })
  }

  if (loading) {
    return (
      <Card className="w-full max-w-2xl mx-auto">
        <CardContent className="p-8">
          <div className="animate-pulse space-y-4">
            <div className="h-8 bg-gray-200 rounded w-3/4"></div>
            <div className="h-4 bg-gray-200 rounded w-1/2"></div>
            <div className="h-32 bg-gray-200 rounded"></div>
          </div>
        </CardContent>
      </Card>
    )
  }

  if (!certificateData) {
    return (
      <Card className="w-full max-w-2xl mx-auto">
        <CardContent className="p-8 text-center">
          <Award className="h-16 w-16 mx-auto text-gray-400 mb-4" />
          <h3 className="text-lg font-semibold text-gray-600">Certificate Not Found</h3>
          <p className="text-gray-500">Token ID #{tokenId} could not be loaded</p>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card className="w-full max-w-2xl mx-auto bg-gradient-to-br from-blue-50 to-green-50 border-2 border-blue-200">
      <CardHeader className="text-center pb-4">
        <div className="flex justify-center mb-4">
          <Award className="h-16 w-16 text-blue-600" />
        </div>
        <CardTitle className="text-2xl font-bold text-blue-800">
          Blue Carbon Certificate
        </CardTitle>
        <p className="text-blue-600">Token ID: #{certificateData.tokenId}</p>
        <Badge 
          variant={certificateData.status === 'active' ? 'default' : 
                  certificateData.status === 'retired' ? 'secondary' : 'outline'}
          className="mx-auto"
        >
          {certificateData.status.toUpperCase()}
        </Badge>
      </CardHeader>

      <CardContent className="space-y-6">
        {/* Project Information */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <h4 className="font-semibold text-gray-700 flex items-center gap-2">
              <Leaf className="h-4 w-4" />
              Project Details
            </h4>
            <p className="text-sm"><strong>Name:</strong> {certificateData.projectName}</p>
            <p className="text-sm flex items-center gap-1">
              <MapPin className="h-3 w-3" />
              <strong>Location:</strong> {certificateData.location}
            </p>
            <p className="text-sm"><strong>Ecosystem:</strong> {certificateData.ecosystem}</p>
            <p className="text-sm"><strong>Area:</strong> {certificateData.area} hectares</p>
          </div>

          <div className="space-y-2">
            <h4 className="font-semibold text-gray-700 flex items-center gap-2">
              <Calendar className="h-4 w-4" />
              Certification Details
            </h4>
            <p className="text-sm"><strong>Carbon Credits:</strong> {certificateData.carbonCredits} tCO2</p>
            <p className="text-sm"><strong>Vintage:</strong> {certificateData.vintage}</p>
            <p className="text-sm"><strong>Methodology:</strong> {certificateData.methodology}</p>
            <p className="text-sm"><strong>Verified:</strong> {new Date(certificateData.verificationDate).toLocaleDateString()}</p>
          </div>
        </div>

        {/* Blockchain Information */}
        <div className="bg-white/50 p-4 rounded-lg">
          <h4 className="font-semibold text-gray-700 mb-2">Blockchain Verification</h4>
          <p className="text-xs text-gray-600 break-all">
            <strong>Transaction Hash:</strong> {certificateData.blockchainTxHash}
          </p>
          <p className="text-xs text-gray-600 break-all mt-1">
            <strong>IPFS Hash:</strong> {certificateData.ipfsHash}
          </p>
        </div>

        {/* Action Buttons */}
        <div className="flex gap-2 justify-center">
          <Button onClick={downloadCertificate} variant="outline" size="sm">
            <Download className="h-4 w-4 mr-2" />
            Download PDF
          </Button>
          <Button onClick={shareCertificate} variant="outline" size="sm">
            <Share2 className="h-4 w-4 mr-2" />
            Share
          </Button>
        </div>

        {/* QR Code for Verification */}
        <div className="text-center">
          <div className="inline-block p-4 bg-white rounded-lg">
            <div className="w-32 h-32 bg-gray-200 rounded flex items-center justify-center">
              <span className="text-xs text-gray-500">QR Code</span>
            </div>
          </div>
          <p className="text-xs text-gray-500 mt-2">Scan to verify on blockchain</p>
        </div>
      </CardContent>
    </Card>
  )
}

export default CertificateDisplay
