"use client"

import React, { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { 
  AlertTriangle, 
  Satellite, 
  Waves, 
  TreePine, 
  Factory, 
  Thermometer,
  Eye,
  Bell,
  MapPin,
  Calendar,
  TrendingUp,
  Shield
} from 'lucide-react'
import { motion } from 'framer-motion'

interface ThreatAlert {
  id: string
  type: 'deforestation' | 'pollution' | 'erosion' | 'temperature' | 'salinity' | 'human_activity'
  severity: 'low' | 'medium' | 'high' | 'critical'
  location: { latitude: number; longitude: number }
  description: string
  timestamp: Date
  projectId: string
  source: 'satellite' | 'iot' | 'manual' | 'ai_prediction'
  confidence: number
  actionRequired: boolean
}

interface ThreatMonitoringProps {
  projectId?: string
}

export function ThreatMonitoring({ projectId }: ThreatMonitoringProps) {
  const [threats, setThreats] = useState<ThreatAlert[]>([])
  const [loading, setLoading] = useState(true)
  const [activeTab, setActiveTab] = useState('overview')
  const [monitoringEnabled, setMonitoringEnabled] = useState(true)

  useEffect(() => {
    fetchThreats()
    
    // Set up real-time monitoring
    const interval = setInterval(fetchThreats, 30000) // Check every 30 seconds
    
    return () => clearInterval(interval)
  }, [projectId])

  const fetchThreats = async () => {
    try {
      const response = await fetch(`/api/threats${projectId ? `?projectId=${projectId}` : ''}`)
      const data = await response.json()
      setThreats(data.threats || [])
    } catch (error) {
      console.error('Error fetching threats:', error)
    } finally {
      setLoading(false)
    }
  }

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'critical': return 'bg-red-500'
      case 'high': return 'bg-orange-500'
      case 'medium': return 'bg-yellow-500'
      case 'low': return 'bg-blue-500'
      default: return 'bg-gray-500'
    }
  }

  const getThreatIcon = (type: string) => {
    switch (type) {
      case 'deforestation': return <TreePine className="w-4 h-4" />
      case 'pollution': return <Factory className="w-4 h-4" />
      case 'erosion': return <Waves className="w-4 h-4" />
      case 'temperature': return <Thermometer className="w-4 h-4" />
      case 'salinity': return <Waves className="w-4 h-4" />
      case 'human_activity': return <Eye className="w-4 h-4" />
      default: return <AlertTriangle className="w-4 h-4" />
    }
  }

  const criticalThreats = threats.filter(t => t.severity === 'critical')
  const highThreats = threats.filter(t => t.severity === 'high')
  const recentThreats = threats.filter(t => 
    new Date().getTime() - t.timestamp.getTime() < 24 * 60 * 60 * 1000
  )

  const mockThreats: ThreatAlert[] = [
    {
      id: '1',
      type: 'deforestation',
      severity: 'high',
      location: { latitude: 21.4735, longitude: 88.4078 },
      description: 'Satellite imagery shows 2.3 hectares of mangrove loss in Sundarbans sector 7',
      timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000),
      projectId: 'proj-1',
      source: 'satellite',
      confidence: 0.89,
      actionRequired: true
    },
    {
      id: '2',
      type: 'pollution',
      severity: 'medium',
      location: { latitude: 9.9312, longitude: 76.2673 },
      description: 'Water quality sensors detect elevated nitrogen levels (15.2 mg/L)',
      timestamp: new Date(Date.now() - 4 * 60 * 60 * 1000),
      projectId: 'proj-2',
      source: 'iot',
      confidence: 0.95,
      actionRequired: true
    },
    {
      id: '3',
      type: 'erosion',
      severity: 'critical',
      location: { latitude: 11.9416, longitude: 79.8083 },
      description: 'Coastal erosion rate increased to 3.2m/year, threatening seagrass beds',
      timestamp: new Date(Date.now() - 6 * 60 * 60 * 1000),
      projectId: 'proj-2',
      source: 'satellite',
      confidence: 0.92,
      actionRequired: true
    },
    {
      id: '4',
      type: 'temperature',
      severity: 'medium',
      location: { latitude: 21.4735, longitude: 88.4078 },
      description: 'Water temperature anomaly: 3.2°C above seasonal average',
      timestamp: new Date(Date.now() - 8 * 60 * 60 * 1000),
      projectId: 'proj-1',
      source: 'iot',
      confidence: 0.87,
      actionRequired: false
    },
    {
      id: '5',
      type: 'human_activity',
      severity: 'high',
      location: { latitude: 9.9312, longitude: 76.2673 },
      description: 'Unauthorized boat activity detected in protected seagrass area',
      timestamp: new Date(Date.now() - 12 * 60 * 60 * 1000),
      projectId: 'proj-2',
      source: 'ai_prediction',
      confidence: 0.78,
      actionRequired: true
    }
  ]

  const displayThreats = threats.length > 0 ? threats : mockThreats

  if (loading) {
    return (
      <Card className="w-full">
        <CardContent className="p-8">
          <div className="animate-pulse space-y-4">
            <div className="h-8 bg-gray-200 rounded w-1/3"></div>
            <div className="h-32 bg-gray-200 rounded"></div>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="w-full space-y-6">
      {/* Header */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Shield className="w-6 h-6 text-blue-600" />
              <CardTitle className="text-xl">Threat Monitoring System</CardTitle>
              <Badge variant={monitoringEnabled ? "default" : "secondary"}>
                {monitoringEnabled ? "Active" : "Inactive"}
              </Badge>
            </div>
            <Button
              onClick={() => setMonitoringEnabled(!monitoringEnabled)}
              variant={monitoringEnabled ? "outline" : "default"}
            >
              {monitoringEnabled ? "Disable" : "Enable"} Monitoring
            </Button>
          </div>
        </CardHeader>
      </Card>

      {/* Alert Summary */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="border-red-200 bg-red-50">
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-red-600" />
              <div>
                <p className="text-2xl font-bold text-red-600">{criticalThreats.length}</p>
                <p className="text-sm text-red-600">Critical Threats</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-orange-200 bg-orange-50">
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-orange-600" />
              <div>
                <p className="text-2xl font-bold text-orange-600">{highThreats.length}</p>
                <p className="text-sm text-orange-600">High Priority</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-blue-200 bg-blue-50">
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <Bell className="w-5 h-5 text-blue-600" />
              <div>
                <p className="text-2xl font-bold text-blue-600">{recentThreats.length}</p>
                <p className="text-sm text-blue-600">Last 24 Hours</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-green-200 bg-green-50">
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <Satellite className="w-5 h-5 text-green-600" />
              <div>
                <p className="text-2xl font-bold text-green-600">98.2%</p>
                <p className="text-sm text-green-600">System Uptime</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Content */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="alerts">Active Alerts</TabsTrigger>
          <TabsTrigger value="satellite">Satellite Data</TabsTrigger>
          <TabsTrigger value="predictions">AI Predictions</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Recent Threat Activity</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {displayThreats.slice(0, 5).map((threat) => (
                  <motion.div
                    key={threat.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="flex items-start gap-4 p-4 border rounded-lg"
                  >
                    <div className={`p-2 rounded-full ${getSeverityColor(threat.severity)}`}>
                      {getThreatIcon(threat.type)}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <h4 className="font-semibold capitalize">{threat.type.replace('_', ' ')}</h4>
                        <Badge variant={threat.severity === 'critical' ? 'destructive' : 'outline'}>
                          {threat.severity}
                        </Badge>
                        <Badge variant="secondary">
                          {(threat.confidence * 100).toFixed(0)}% confidence
                        </Badge>
                      </div>
                      <p className="text-sm text-gray-600 mb-2">{threat.description}</p>
                      <div className="flex items-center gap-4 text-xs text-gray-500">
                        <span className="flex items-center gap-1">
                          <Calendar className="w-3 h-3" />
                          {threat.timestamp.toLocaleString()}
                        </span>
                        <span className="flex items-center gap-1">
                          <MapPin className="w-3 h-3" />
                          {threat.location.latitude.toFixed(4)}, {threat.location.longitude.toFixed(4)}
                        </span>
                        <span className="flex items-center gap-1">
                          <Satellite className="w-3 h-3" />
                          {threat.source}
                        </span>
                      </div>
                    </div>
                    {threat.actionRequired && (
                      <Button size="sm" variant="outline">
                        Take Action
                      </Button>
                    )}
                  </motion.div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="alerts" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Active Threat Alerts</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {displayThreats
                  .filter(t => t.actionRequired)
                  .map((threat) => (
                    <div key={threat.id} className="p-4 border-l-4 border-red-500 bg-red-50 rounded">
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="font-semibold text-red-800 capitalize">
                          {threat.type.replace('_', ' ')} Alert
                        </h4>
                        <Badge variant="destructive">{threat.severity}</Badge>
                      </div>
                      <p className="text-red-700 mb-3">{threat.description}</p>
                      <div className="flex gap-2">
                        <Button size="sm" className="bg-red-600 hover:bg-red-700">
                          Investigate
                        </Button>
                        <Button size="sm" variant="outline">
                          Mark as Resolved
                        </Button>
                        <Button size="sm" variant="outline">
                          Escalate
                        </Button>
                      </div>
                    </div>
                  ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="satellite" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Satellite Monitoring</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <h4 className="font-semibold">Deforestation Detection</h4>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span>Forest Cover Change</span>
                      <span className="text-red-600">-2.3 ha</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Detection Confidence</span>
                      <span>89%</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Last Update</span>
                      <span>2 hours ago</span>
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <h4 className="font-semibold">Coastal Erosion</h4>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span>Erosion Rate</span>
                      <span className="text-orange-600">3.2 m/year</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Affected Area</span>
                      <span>1.8 km coastline</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Trend</span>
                      <span className="text-red-600 flex items-center gap-1">
                        <TrendingUp className="w-3 h-3" />
                        Increasing
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="predictions" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>AI Threat Predictions</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                  <h4 className="font-semibold text-yellow-800 mb-2">
                    Predicted Threat: Pollution Event
                  </h4>
                  <p className="text-yellow-700 mb-3">
                    AI models predict 73% probability of water pollution event in next 48 hours 
                    based on upstream industrial activity and weather patterns.
                  </p>
                  <div className="flex gap-2">
                    <Button size="sm" variant="outline">
                      View Details
                    </Button>
                    <Button size="sm" variant="outline">
                      Set Alert
                    </Button>
                  </div>
                </div>

                <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                  <h4 className="font-semibold text-blue-800 mb-2">
                    Climate Risk Assessment
                  </h4>
                  <p className="text-blue-700 mb-3">
                    Rising sea temperatures may stress mangrove ecosystems. 
                    Recommended adaptive management measures available.
                  </p>
                  <div className="flex gap-2">
                    <Button size="sm" variant="outline">
                      View Recommendations
                    </Button>
                    <Button size="sm" variant="outline">
                      Download Report
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

export default ThreatMonitoring
