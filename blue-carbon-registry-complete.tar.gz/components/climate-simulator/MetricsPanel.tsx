'use client';

import { Users, Thermometer, AlertTriangle, Droplets, Snowflake, Leaf, Zap } from 'lucide-react';

interface EarthMetrics {
  co2Level: number;
  toxicityLevel: number;
  temperature: number;
  humanPopulation: number;
  animalPopulation: number;
  plantPopulation: number;
  oceanAcidity: number;
  iceCapMelting: number;
}

interface MetricsPanelProps {
  metrics: EarthMetrics;
  pollutionLevel: number;
}

const formatNumber = (num: number): string => {
  if (num >= 1e9) return (num / 1e9).toFixed(1) + 'B';
  if (num >= 1e6) return (num / 1e6).toFixed(1) + 'M';
  if (num >= 1e3) return (num / 1e3).toFixed(1) + 'K';
  return num.toFixed(0);
};

export default function MetricsPanel({ metrics, pollutionLevel }: MetricsPanelProps) {
  const getStatusColor = (value: number, isReverse = false) => {
    const threshold = isReverse ? 100 - value : value;
    if (threshold <= 30) return 'text-green-500';
    if (threshold <= 60) return 'text-yellow-500';
    if (threshold <= 80) return 'text-orange-500';
    return 'text-red-500';
  };

  const getProgressColor = (value: number, isReverse = false) => {
    const threshold = isReverse ? 100 - value : value;
    if (threshold <= 30) return 'bg-green-500';
    if (threshold <= 60) return 'bg-yellow-500';
    if (threshold <= 80) return 'bg-orange-500';
    return 'bg-red-500';
  };

  const MetricCard = ({ 
    icon: Icon, 
    label, 
    value, 
    unit, 
    percentage, 
    isReverse = false 
  }: {
    icon: any;
    label: string;
    value: number;
    unit: string;
    percentage: number;
    isReverse?: boolean;
  }) => (
    <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4 border border-white/20">
      <div className="flex items-center gap-3 mb-3">
        <Icon className={`w-5 h-5 ${getStatusColor(percentage, isReverse)}`} />
        <span className="text-sm font-medium text-white">{label}</span>
      </div>
      <div className="space-y-2">
        <div className="flex justify-between items-center">
          <span className={`text-lg font-bold ${getStatusColor(percentage, isReverse)}`}>
            {formatNumber(value)}{unit}
          </span>
          <span className={`text-sm ${getStatusColor(percentage, isReverse)}`}>
            {percentage.toFixed(1)}%
          </span>
        </div>
        <div className="w-full bg-gray-700 rounded-full h-2">
          <div
            className={`h-2 rounded-full transition-all duration-500 ${getProgressColor(percentage, isReverse)}`}
            style={{ width: `${percentage}%` }}
          />
        </div>
      </div>
    </div>
  );

  const overallHealth = (
    (100 - metrics.co2Level) +
    (100 - metrics.toxicityLevel) +
    (100 - metrics.temperature) +
    metrics.humanPopulation / 1000000 +
    metrics.animalPopulation / 1000000 +
    metrics.plantPopulation / 1000000 +
    (100 - metrics.oceanAcidity) +
    (100 - metrics.iceCapMelting)
  ) / 8;

  return (
    <div className="space-y-6">
      {/* Overall Health Status */}
      <div className="bg-gradient-to-r from-blue-600/20 to-green-600/20 backdrop-blur-sm rounded-xl p-6 border border-white/20">
        <div className="flex items-center gap-3 mb-4">
          <AlertTriangle className={`w-6 h-6 ${getStatusColor(100 - overallHealth)}`} />
          <h2 className="text-xl font-bold text-white">Planet Earth Status</h2>
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <span className="text-sm text-gray-300">Overall Health</span>
            <div className={`text-2xl font-bold ${getStatusColor(100 - overallHealth)}`}>
              {overallHealth.toFixed(1)}%
            </div>
          </div>
          <div>
            <span className="text-sm text-gray-300">Pollution Level</span>
            <div className={`text-2xl font-bold ${getStatusColor(pollutionLevel)}`}>
              {pollutionLevel.toFixed(1)}%
            </div>
          </div>
        </div>
        <div className="mt-4">
          <div className="w-full bg-gray-700 rounded-full h-3">
            <div
              className={`h-3 rounded-full transition-all duration-1000 ${getProgressColor(100 - overallHealth)}`}
              style={{ width: `${overallHealth}%` }}
            />
          </div>
        </div>
      </div>

      {/* Environmental Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <MetricCard
          icon={Zap}
          label="CO2 Levels"
          value={metrics.co2Level}
          unit="ppm"
          percentage={metrics.co2Level}
        />
        <MetricCard
          icon={AlertTriangle}
          label="Toxicity Level"
          value={metrics.toxicityLevel}
          unit="%"
          percentage={metrics.toxicityLevel}
        />
        <MetricCard
          icon={Thermometer}
          label="Temperature"
          value={metrics.temperature}
          unit="°C"
          percentage={metrics.temperature}
        />
        <MetricCard
          icon={Droplets}
          label="Ocean Acidity"
          value={metrics.oceanAcidity}
          unit="pH"
          percentage={metrics.oceanAcidity}
        />
        <MetricCard
          icon={Snowflake}
          label="Ice Cap Melting"
          value={metrics.iceCapMelting}
          unit="%"
          percentage={metrics.iceCapMelting}
        />
      </div>

      {/* Population Metrics */}
      <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 border border-white/20">
        <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
          <Users className="w-5 h-5" />
          Population Statistics
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <MetricCard
            icon={Users}
            label="Human Population"
            value={metrics.humanPopulation}
            unit=""
            percentage={(metrics.humanPopulation / 10000000) * 100}
            isReverse={true}
          />
          <MetricCard
            icon={Users}
            label="Animal Population"
            value={metrics.animalPopulation}
            unit=""
            percentage={(metrics.animalPopulation / 10000000) * 100}
            isReverse={true}
          />
          <MetricCard
            icon={Leaf}
            label="Plant Population"
            value={metrics.plantPopulation}
            unit=""
            percentage={(metrics.plantPopulation / 10000000) * 100}
            isReverse={true}
          />
        </div>
      </div>

      {/* Blue Carbon Impact */}
      <div className="bg-gradient-to-r from-blue-600/20 to-teal-600/20 backdrop-blur-sm rounded-xl p-6 border border-white/20">
        <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
          <Leaf className="w-5 h-5 text-blue-400" />
          Blue Carbon Impact Potential
        </h3>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <span className="text-sm text-gray-300">CO2 Reduction Potential</span>
            <div className="text-xl font-bold text-blue-400">
              -{Math.min(metrics.co2Level * 0.3, 50).toFixed(1)} ppm
            </div>
          </div>
          <div>
            <span className="text-sm text-gray-300">Ocean Health Improvement</span>
            <div className="text-xl font-bold text-teal-400">
              +{Math.min(metrics.oceanAcidity * 0.2, 30).toFixed(1)}%
            </div>
          </div>
        </div>
        <p className="text-sm text-gray-300 mt-3">
          Blue carbon ecosystems like mangroves and seagrass can significantly reduce these environmental impacts.
        </p>
      </div>
    </div>
  );
}
