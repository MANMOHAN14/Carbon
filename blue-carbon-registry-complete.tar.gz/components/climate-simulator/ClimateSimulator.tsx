'use client';

import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import Globe from './Globe';
import MetricsPanel from './MetricsPanel';
import { Play, Pause, RotateCcw, Zap } from 'lucide-react';

interface EarthMetrics {
  co2Level: number;
  toxicityLevel: number;
  temperature: number;
  humanPopulation: number;
  animalPopulation: number;
  plantPopulation: number;
  oceanAcidity: number;
  iceCapMelting: number;
}

interface AICommand {
  command: string;
  analysis: string;
  timestamp: Date;
  severity: 'low' | 'medium' | 'high' | 'critical';
}

export default function ClimateSimulator() {
  const [isRunning, setIsRunning] = useState(false);
  const [currentYear, setCurrentYear] = useState(2024);
  const [speed, setSpeed] = useState(1);
  const [showMetrics, setShowMetrics] = useState(true);
  
  const [metrics, setMetrics] = useState<EarthMetrics>({
    co2Level: 420,
    toxicityLevel: 35,
    temperature: 15,
    humanPopulation: 8000000000,
    animalPopulation: 2000000000,
    plantPopulation: 390000000000,
    oceanAcidity: 8.1,
    iceCapMelting: 15
  });

  const [aiCommands, setAiCommands] = useState<AICommand[]>([
    {
      command: "ANALYZE_CLIMATE_TRENDS",
      analysis: "CO2 levels rising at 2.5ppm/year. Immediate action required.",
      timestamp: new Date(),
      severity: 'high'
    }
  ]);

  const pollutionLevel = (metrics.co2Level - 280) / 4; // Normalized pollution level

  // AI-driven simulation logic
  useEffect(() => {
    if (!isRunning) return;

    const interval = setInterval(() => {
      setCurrentYear(prev => prev + 1);
      
      setMetrics(prev => {
        const newMetrics = { ...prev };
        
        // Simulate climate degradation over time
        newMetrics.co2Level += Math.random() * 3 + 1; // 1-4 ppm increase per year
        newMetrics.toxicityLevel += Math.random() * 2;
        newMetrics.temperature += Math.random() * 0.5;
        newMetrics.oceanAcidity += Math.random() * 0.1;
        newMetrics.iceCapMelting += Math.random() * 2;
        
        // Population changes
        newMetrics.humanPopulation += Math.random() * 50000000;
        newMetrics.animalPopulation -= Math.random() * 10000000; // Declining wildlife
        newMetrics.plantPopulation -= Math.random() * 1000000000; // Deforestation
        
        // Cap values at realistic limits
        newMetrics.co2Level = Math.min(newMetrics.co2Level, 600);
        newMetrics.toxicityLevel = Math.min(newMetrics.toxicityLevel, 100);
        newMetrics.temperature = Math.min(newMetrics.temperature, 25);
        newMetrics.oceanAcidity = Math.min(newMetrics.oceanAcidity, 14);
        newMetrics.iceCapMelting = Math.min(newMetrics.iceCapMelting, 100);
        
        return newMetrics;
      });

      // Generate AI commands based on metrics
      if (Math.random() < 0.3) { // 30% chance each update
        const commands = [
          {
            command: "EMERGENCY_PROTOCOL_ACTIVATED",
            analysis: `Critical CO2 levels detected: ${metrics.co2Level.toFixed(1)}ppm`,
            severity: 'critical' as const
          },
          {
            command: "BIODIVERSITY_ALERT",
            analysis: `Animal population declining: ${(metrics.animalPopulation / 1000000).toFixed(1)}M remaining`,
            severity: 'high' as const
          },
          {
            command: "OCEAN_ACIDIFICATION_WARNING",
            analysis: `Ocean pH dropping: ${metrics.oceanAcidity.toFixed(2)} - Marine life at risk`,
            severity: 'medium' as const
          },
          {
            command: "TEMPERATURE_ANOMALY",
            analysis: `Global temperature: ${metrics.temperature.toFixed(1)}°C - Above safe limits`,
            severity: 'high' as const
          }
        ];
        
        const randomCommand = commands[Math.floor(Math.random() * commands.length)];
        setAiCommands(prev => [
          {
            ...randomCommand,
            timestamp: new Date()
          },
          ...prev.slice(0, 4) // Keep only last 5 commands
        ]);
      }
    }, 2000 / speed);

    return () => clearInterval(interval);
  }, [isRunning, speed, metrics]);

  const resetSimulation = () => {
    setCurrentYear(2024);
    setMetrics({
      co2Level: 420,
      toxicityLevel: 35,
      temperature: 15,
      humanPopulation: 8000000000,
      animalPopulation: 2000000000,
      plantPopulation: 390000000000,
      oceanAcidity: 8.1,
      iceCapMelting: 15
    });
    setAiCommands([]);
    setIsRunning(false);
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'critical': return 'text-red-500 bg-red-500/20';
      case 'high': return 'text-orange-500 bg-orange-500/20';
      case 'medium': return 'text-yellow-500 bg-yellow-500/20';
      default: return 'text-blue-500 bg-blue-500/20';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-800 text-white">
      {/* Header */}
      <div className="container mx-auto px-4 py-6">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-8"
        >
          <h1 className="text-4xl md:text-6xl font-bold mb-4 bg-gradient-to-r from-blue-400 to-green-400 bg-clip-text text-transparent">
            AI Climate Simulator
          </h1>
          <p className="text-xl text-gray-300 mb-6">
            Real-time Earth simulation powered by AI - Witness the impact of climate change
          </p>
          
          {/* Controls */}
          <div className="flex flex-wrap justify-center gap-4 mb-6">
            <button
              onClick={() => setIsRunning(!isRunning)}
              className={`flex items-center gap-2 px-6 py-3 rounded-lg font-semibold transition-all ${
                isRunning 
                  ? 'bg-red-600 hover:bg-red-700' 
                  : 'bg-green-600 hover:bg-green-700'
              }`}
            >
              {isRunning ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5" />}
              {isRunning ? 'Pause' : 'Start'} Simulation
            </button>
            
            <button
              onClick={resetSimulation}
              className="flex items-center gap-2 px-6 py-3 bg-gray-600 hover:bg-gray-700 rounded-lg font-semibold transition-all"
            >
              <RotateCcw className="w-5 h-5" />
              Reset
            </button>
            
            <button
              onClick={() => setShowMetrics(!showMetrics)}
              className="flex items-center gap-2 px-6 py-3 bg-blue-600 hover:bg-blue-700 rounded-lg font-semibold transition-all"
            >
              <Zap className="w-5 h-5" />
              {showMetrics ? 'Hide' : 'Show'} Metrics
            </button>
          </div>

          {/* Year and Speed Controls */}
          <div className="flex flex-wrap justify-center items-center gap-6 text-lg">
            <div className="bg-white/10 px-4 py-2 rounded-lg">
              <span className="text-gray-300">Year: </span>
              <span className="font-bold text-blue-400">{currentYear}</span>
            </div>
            
            <div className="flex items-center gap-2">
              <span className="text-gray-300">Speed:</span>
              <select
                value={speed}
                onChange={(e) => setSpeed(Number(e.target.value))}
                className="bg-white/10 border border-white/20 rounded px-3 py-1 text-white"
              >
                <option value={0.5}>0.5x</option>
                <option value={1}>1x</option>
                <option value={2}>2x</option>
                <option value={5}>5x</option>
              </select>
            </div>
          </div>
        </motion.div>

        {/* Main Content */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Globe Visualization */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
            className="bg-white/5 backdrop-blur-sm rounded-2xl p-6 border border-white/10"
          >
            <h2 className="text-2xl font-bold mb-4 text-center">Earth Simulation</h2>
            <div className="aspect-square">
              <Globe metrics={metrics} pollutionLevel={pollutionLevel} />
            </div>
          </motion.div>

          {/* Metrics Panel */}
          {showMetrics && (
            <motion.div
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.4 }}
              className="space-y-6"
            >
              <MetricsPanel metrics={metrics} pollutionLevel={pollutionLevel} />
            </motion.div>
          )}
        </div>

        {/* AI Commands Panel */}
        {aiCommands.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
            className="mt-8 bg-black/30 backdrop-blur-sm rounded-2xl p-6 border border-white/10"
          >
            <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
              <Zap className="w-5 h-5 text-yellow-400" />
              AI Climate Analysis
            </h3>
            <div className="space-y-3 max-h-60 overflow-y-auto">
              {aiCommands.map((cmd, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className={`p-3 rounded-lg border ${getSeverityColor(cmd.severity)}`}
                >
                  <div className="flex justify-between items-start mb-2">
                    <span className="font-mono text-sm font-bold">{cmd.command}</span>
                    <span className="text-xs text-gray-400">
                      {cmd.timestamp.toLocaleTimeString()}
                    </span>
                  </div>
                  <p className="text-sm text-gray-300">{cmd.analysis}</p>
                </motion.div>
              ))}
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
}
